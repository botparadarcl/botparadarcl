const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

async function createCLMessage() {
    const clEmbed = new EmbedBuilder()
        .setColor('#000000')
        .setTitle('Painel CL\n\n')
        .setDescription(
            'Utilize este sistema para deletar suas mensagens privadas de forma segura e controlada.\n\n' +
            '•   Token - Gerenciar o token da sua conta.\n' +
            '•   CL - Deleta suas mensagens privadas com uma pessoa especifica atraves do id da pessoa.\n\n'
        )
        .setFooter({ 
            text: 'Sistema CL'
        })
        .setTimestamp();

    // Botões na mesma linha: Token e CL
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('token_menu')
            .setLabel('Token')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('cl_dm')
            .setLabel('CL')
            .setStyle(ButtonStyle.Secondary)
    );

    return { 
        embeds: [clEmbed], 
        components: [row1]
    };
}

module.exports = { createCLMessage };