const fs = require('fs');
const path = require('path');
const cooldownPath = path.join(__dirname, 'renCooldown.json');
const usedPath = path.join(__dirname, 'usedOnce.json');
const tokensPath = path.join(__dirname, 'userTokens.json');

function ensureFiles() {
  if (!fs.existsSync(cooldownPath)) {
    fs.writeFileSync(cooldownPath, JSON.stringify({}));
  }
  if (!fs.existsSync(usedPath)) {
    fs.writeFileSync(usedPath, JSON.stringify({}));
  }
  if (!fs.existsSync(tokensPath)) {
    fs.writeFileSync(tokensPath, JSON.stringify({}));
  }
}

function readCooldown() {
  ensureFiles();
  try {
    const data = fs.readFileSync(cooldownPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler cooldown:', error);
    return {};
  }
}

function writeCooldown(data) {
  try {
    fs.writeFileSync(cooldownPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar cooldown:', error);
    return false;
  }
}

function readUsed() {
  ensureFiles();
  try {
    const data = fs.readFileSync(usedPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler used:', error);
    return {};
  }
}

function writeUsed(data) {
  try {
    fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar used:', error);
    return false;
  }
}

function readTokens() {
  ensureFiles();
  try {
    const data = fs.readFileSync(tokensPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler tokens:', error);
    return {};
  }
}

function writeTokens(data) {
  try {
    fs.writeFileSync(tokensPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar tokens:', error);
    return false;
  }
}

async function sendRestartNotification(client) {
  try {
    const dbPath = path.join(__dirname, 'userKeys.json');
    if (fs.existsSync(dbPath)) {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      if (db.notChannel) {
        const channel = client.channels.cache.get(db.notChannel);
        if (channel) {
          const { EmbedBuilder } = require('discord.js');
          const restartEmbed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setTitle('Reinicio Preventivo do Sistema')
            .setDescription('Sistema reiniciado para otimizacao de performance. Todos os processos ativos foram finalizados para evitar sobrecarga.\n\nTokens foram preservados e o sistema esta pronto para uso normal.\nProximo reinicio preventivo em 2 horas.')
            .setTimestamp();

          await channel.send({ embeds: [restartEmbed] });
        }
      }
    }
  } catch (error) {
    console.error('Erro ao enviar notificacao de reinicio:', error);
  }
}

async function doReset(interaction, autoRestart = false, client = null) {
  try {
    const tokensBackup = readTokens();
    
    writeUsed({});
    writeCooldown({});

    writeTokens(tokensBackup);

    console.log(`Sistema reiniciado por ${interaction?.user?.tag || 'SISTEMA'}`);
    console.log(`Processos ativos limpos - Tokens mantidos: ${Object.keys(tokensBackup).length}`);

    if (autoRestart && client) {
      await sendRestartNotification(client);
    }

    if (interaction && !autoRestart) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: `Sistema reiniciado com sucesso.\n` +
            `Todos os processos ativos foram finalizados para evitar sobrecarga.\n` +
            `Tokens preservados - usuarios podem continuar usando normalmente.`,
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: `Sistema reiniciado com sucesso.\n` +
            `Todos os processos ativos foram finalizados para evitar sobrecarga.\n` +
            `Tokens preservados - usuarios podem continuar usando normalmente.`,
          ephemeral: true
        });
      }
    }

    return true;

  } catch (error) {
    console.error('Erro no doReset:', error);

    if (interaction && !autoRestart) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: 'Erro ao reiniciar o sistema. Tente novamente.',
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: 'Erro ao reiniciar o sistema. Tente novamente.',
          ephemeral: true
        });
      }
    }
    return false;
  }
}

async function autoRestart(client) {
  try {
    console.log('Iniciando reinicio preventivo programado...');

    const dbPath = path.join(__dirname, 'userKeys.json');
    let notChannel = null;
    let logsChannel = null;

    if (fs.existsSync(dbPath)) {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      if (db.notChannel) {
        notChannel = client.channels.cache.get(db.notChannel);
      }
      if (db.logsChannel) {
        logsChannel = client.channels.cache.get(db.logsChannel);
      }
    }

    const targetChannel = notChannel || logsChannel;

    if (targetChannel) {
      await targetChannel.send({
        content: 'AVISO DE REINICIO PREVENTIVO\n\n' +
          'O sistema sera reiniciado em 5 minutos para otimizacao de performance.\n' +
          'Processos ativos serao finalizados para evitar sobrecarga.\n' +
          'Tokens serao preservados - nenhum dado sera perdido.'
      });
    }

    setTimeout(async () => {
      try {
        await doReset(null, true, client);
        console.log('Reinicio preventivo concluido');
        scheduleNextRestart(client);
      } catch (error) {
        console.error('Erro no reinicio preventivo:', error);
      }
    }, 5 * 60 * 1000);

  } catch (error) {
    console.error('Erro no agendamento do reinicio preventivo:', error);
  }
}

function scheduleNextRestart(client) {
  const twoHours = 2 * 60 * 60 * 1000;

  setTimeout(() => {
    autoRestart(client);
  }, twoHours);

  console.log('Proximo reinicio automatico agendado para 2 horas');
}

module.exports = {
  async resetAll(interaction) {
    try {
      console.log(`Solicitacao de reinicio por ${interaction.user.tag}`);

      if (!interaction.member.permissions.has('Administrator')) {
        return interaction.reply({
          content: 'Apenas administradores podem usar este comando.',
          ephemeral: true
        });
      }

      await interaction.reply({
        content: 'Reiniciando sistema CL DM...',
        ephemeral: true
      });
      
      return await doReset(interaction, false);

    } catch (error) {
      console.error('Erro no resetAll:', error);

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: 'Erro ao processar reinicio. Tente novamente.',
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: 'Erro ao processar reinicio. Tente novamente.',
          ephemeral: true
        });
      }
    }
  },

  getSystemStatus() {
    const used = readUsed();
    const tokens = readTokens();

    return {
      inProgress: used.inProgress || false,
      currentUser: used.user || null,
      startTime: used.startTime || null,
      totalTokens: Object.keys(tokens).length
    };
  },

  startAutoRestart(client) {
    console.log('Iniciando sistema de reinicio automatico (2 horas)');
    scheduleNextRestart(client);
  },

  sendRestartNotification
};