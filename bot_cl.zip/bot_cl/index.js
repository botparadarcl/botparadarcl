require('dotenv').config();
const {
  Client, GatewayIntentBits, Partials,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, StringSelectMenuBuilder, PermissionsBitField
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

const cldm = require('./cl_dm.js');
const addToken = require('./add_token.js');
const ren = require('./ren.js');

client.once('ready', () => {
  console.log(`✅ Bot online como ${client.user.tag}`);
  console.log(`📊 Conectado em ${client.guilds.cache.size} servidores`);
});

// ---------- Comando de configuração ----------
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // Comando de configuração
  if (message.content.toLowerCase() === 'cl!config') {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      const warn = await message.reply({
        content: '🚫 Você **não tem permissão** para usar este comando. (Somente administradores)',
      });
      setTimeout(() => {
        warn.delete().catch(() => { });
        message.delete().catch(() => { });
      }, 5000);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('⚙️ Configuração do Bot')
      .setDescription('Escolha um canal para cada função:');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('add_cl').setLabel('Add CL').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('add_ren').setLabel('Add REN').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('add_logs').setLabel('Add LOGS').setStyle(ButtonStyle.Secondary)
    );

    await message.reply({ embeds: [embed], components: [row] });
    return;
  }

  // Comando para verificar status do sistema (apenas admins)
  if (message.content.toLowerCase() === 'cl!status' && message.member.permissions.has('Administrator')) {
    const status = ren.getSystemStatus();

    const statusEmbed = new EmbedBuilder()
      .setColor(status.inProgress ? 0xffa500 : 0x00ff00)
      .setTitle('📊 Status do Sistema CL DM')
      .addFields(
        { name: '🔄 Processo Ativo', value: status.inProgress ? '✅ Sim' : '❌ Não', inline: true },
        { name: '👤 Usuário Atual', value: status.currentUser ? `<@${status.currentUser}>` : 'Nenhum', inline: true },
        { name: '⏰ Início', value: status.startTime ? new Date(status.startTime).toLocaleString('pt-BR') : 'N/A', inline: true },
        { name: '🔐 Tokens', value: status.totalTokens.toString(), inline: true },
        { name: '🕒 Último Reinício', value: status.lastRestart ? new Date(status.lastRestart).toLocaleString('pt-BR') : 'Nunca', inline: true }
      )
      .setFooter({ text: 'Status em tempo real' })
      .setTimestamp();

    await message.reply({ embeds: [statusEmbed] });
    await message.delete().catch(() => { });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton() && !interaction.isStringSelectMenu() && !interaction.isModalSubmit()) return;

  try {
    // ----- Seleção de canal -----
    if (interaction.isButton() && ['add_cl', 'add_ren', 'add_logs'].includes(interaction.customId)) {
      const channelSelect = new StringSelectMenuBuilder()
        .setCustomId(`channel_select_${interaction.customId}`)
        .setPlaceholder('Selecione um canal')
        .setMinValues(1).setMaxValues(1)
        .addOptions(
          interaction.guild.channels.cache
            .filter(c => c.isTextBased() && c.viewable)
            .map(c => ({ label: `#${c.name}`, value: c.id }))
            .slice(0, 25)
        );

      await interaction.reply({
        content: `📋 Escolha o canal para **${interaction.customId.replace('add_', '').toUpperCase()}**:`,
        components: [new ActionRowBuilder().addComponents(channelSelect)],
        ephemeral: true
      });
      return;
    }

    // ----- Após escolher o canal -----
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('channel_select_')) {
      const [, action] = interaction.customId.split('channel_select_');
      const channelId = interaction.values[0];
      const channel = interaction.guild.channels.cache.get(channelId);

      if (!channel) {
        return interaction.update({ content: '❌ Canal não encontrado!', components: [] });
      }

      if (action === 'add_ren') {
        const renEmbed = new EmbedBuilder()
          .setColor('#e67e22')
          .setTitle('♻️ Reiniciar CL DM')
          .setDescription('Administradores podem reiniciar o sistema de limpeza:');

        // REMOVIDA A ROW3 - Botões de administração REN
        // const renRow = new ActionRowBuilder().addComponents(
        //   new ButtonBuilder().setCustomId('ren_global').setLabel('Reiniciar CL DM').setStyle(ButtonStyle.Danger),
        //   new ButtonBuilder().setCustomId('ren_emergency').setLabel('Reinício Emergencial').setStyle(ButtonStyle.Primary)
        // );

        // ENVIAR SEM COMPONENTS (SEM BOTÕES REN)
        await channel.send({ embeds: [renEmbed] });
        await interaction.update({
          content: `✅ **Add REN** configurado em ${channel}`,
          components: []
        });
        return;
      }

      if (action === 'add_cl') {
        const { createCLMessage } = require('./ui_cl_message.js');
        await channel.send(await createCLMessage());
        await interaction.update({
          content: `✅ **Add CL** configurado em ${channel}`,
          components: []
        });
        return;
      }

      if (action === 'add_logs') {
        const dbPath = path.join(__dirname, 'userKeys.json');
        const db = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath, 'utf8')) : {};
        db.logsChannel = channel.id;
        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        await interaction.update({
          content: `✅ **Logs** configurado em ${channel}`,
          components: []
        });
        return;
      }
    }

    // ----- Botões dentro do CL -----
    if (interaction.isButton()) {
      switch (interaction.customId) {
        case 'cl_dm':
          return cldm.start(interaction, client);

        case 'cl_addtoken':
          return addToken.showAddTokenModal(interaction);

        case 'cl_resettoken':
          return addToken.resetToken(interaction);

        case 'cl_comousar':
          const guideEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📖 Guia de Uso - CL DM')
            .setDescription('Sistema de limpeza de mensagens privadas')
            .addFields(
              { name: '1️⃣ ADD TOKEN', value: 'Vincule o token da SUA conta Discord' },
              { name: '2️⃣ CL DM', value: 'Deleta suas mensagens usando SEU token' },
              { name: '3️⃣ RESET TOKEN', value: 'Remove seu token vinculado' },
              { name: '⏱️ Velocidade', value: '1 mensagem a cada 3 segundos' },
              { name: '⚠️ Aviso', value: 'Esta ação é **IRREVERSÍVEL**!' }
            )
            .setFooter({ text: 'Use com responsabilidade' });

          return interaction.reply({ embeds: [guideEmbed], ephemeral: true });

        // REMOVIDOS OS CASES DOS BOTÕES REN
        // case 'ren_global':
        //   return ren.resetAll(interaction, false);

        // case 'ren_emergency':
        //   return ren.resetAll(interaction, true);
      }
    }

    // ----- Modal de token -----
    if (interaction.isModalSubmit() && interaction.customId === 'add_token_modal') {
      return addToken.handleModal(interaction);
    }

  } catch (error) {
    console.error('❌ Erro na interação:', error);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({
        content: '❌ Ocorreu um erro. Tente novamente.',
        ephemeral: true
      });
    } else {
      await interaction.reply({
        content: '❌ Ocorreu um erro. Tente novamente.',
        ephemeral: true
      });
    }
  }
});

// Tratamento de erros globais
process.on('unhandledRejection', (error) => {
  console.error('❌ Erro não tratado:', error);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Exceção não capturada:', error);
});

client.login(process.env.TOKEN).catch(error => {
  console.error('❌ Erro ao fazer login:', error);
  process.exit(1);
});

// Adicione este comando para verificar o status do sistema
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    
    // Comando para verificar status do sistema (apenas admins)
    if (message.content.toLowerCase() === 'cl!status' && message.member.permissions.has('Administrator')) {
        const status = ren.getSystemStatus();
        
        const statusEmbed = new EmbedBuilder()
            .setColor(status.inProgress ? 0xffa500 : 0x00ff00)
            .setTitle('📊 Status do Sistema CL DM')
            .addFields(
                { name: '🔄 Processo Ativo', value: status.inProgress ? '✅ Sim' : '❌ Não', inline: true },
                { name: '👤 Usuário Atual', value: status.currentUser ? `<@${status.currentUser}>` : 'Nenhum', inline: true },
                { name: '⏰ Início', value: status.startTime ? new Date(status.startTime).toLocaleString('pt-BR') : 'N/A', inline: true },
                { name: '🔐 Tokens', value: status.totalTokens.toString(), inline: true },
                { name: '🕒 Último Reinício', value: status.lastRestart ? new Date(status.lastRestart).toLocaleString('pt-BR') : 'Nunca', inline: true }
            )
            .setFooter({ text: 'Status em tempo real' })
            .setTimestamp();
            
        await message.reply({ embeds: [statusEmbed] });
        await message.delete().catch(() => {});
    }
});