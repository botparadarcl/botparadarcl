const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'userTokens.json');

// Garantir que o arquivo existe
if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, '{}');
  console.log('✅ Arquivo userTokens.json criado');
}

function readDB() {
  try {
    if (!fs.existsSync(dbPath)) return {};
    const data = fs.readFileSync(dbPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('❌ Erro ao ler database:', error);
    return {};
  }
}

function writeDB(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('❌ Erro ao salvar database:', error);
    return false;
  }
}

async function validateUserToken(token) {
    try {
        const response = await fetch('https://discord.com/api/v9/users/@me', {
            headers: {
                'Authorization': token,
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            const userData = await response.json();
            return { valid: true, data: userData, type: 'user' };
        } else {
            // Tentar com prefixo Bot (caso seja token de bot)
            const responseBot = await fetch('https://discord.com/api/v9/users/@me', {
                headers: {
                    'Authorization': `Bot ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (responseBot.ok) {
                const userData = await responseBot.json();
                return { valid: true, data: userData, type: 'bot' };
            }
            
            throw new Error(`Token inválido (Status: ${response.status})`);
        }
    } catch (error) {
        throw new Error(`Falha na validação: ${error.message}`);
    }
}

module.exports = {
  async showAddTokenModal(interaction) {
    try {
      console.log(`🔧 Usuário ${interaction.user.tag} solicitou ADD TOKEN`);
      
      const db = readDB();
      if (db[interaction.user.id]) {
        const embed = new EmbedBuilder()
          .setColor(0xffa500)
          .setTitle('⚠️ Token Já Vinculado')
          .setDescription(`Você já possui um token vinculado à sua conta.\n\n**Usuário:** ${db[interaction.user.id].username}\n**Vinculado em:** ${new Date(db[interaction.user.id].addedAt).toLocaleString('pt-BR')}`)
          .setFooter({ text: 'Use RESET TOKEN se quiser alterar' });

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      const modal = new ModalBuilder()
        .setCustomId('add_token_modal')
        .setTitle('🔐 Vincular Token da Sua Conta')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('user_token')
              .setLabel('Token da sua conta Discord')
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder('Cole o token da SUA CONTA aqui...')
              .setRequired(true)
              .setMinLength(50)
              .setMaxLength(100)
          )
        );

      await interaction.showModal(modal);
      console.log(`✅ Modal aberto para ${interaction.user.tag}`);

    } catch (error) {
      console.error('❌ Erro no showAddTokenModal:', error);
      await interaction.reply({ 
        content: '❌ Erro ao abrir o modal. Tente novamente.', 
        ephemeral: true 
      });
    }
  },

  async handleModal(interaction) {
    try {
      console.log(`🔧 Processando token para ${interaction.user.tag}`);
      
      const tokenValue = interaction.fields.getTextInputValue('user_token').trim();
      
      if (!tokenValue) {
        return await interaction.reply({ 
          content: '❌ Token não pode estar vazio.', 
          ephemeral: true 
        });
      }

      // VALIDAÇÃO RELAXADA - Aceita qualquer token que funcione
      console.log(`🔍 Validando token: ${tokenValue.substring(0, 20)}...`);
      
      const validation = await validateUserToken(tokenValue);
      
      // Verificar se o token pertence ao usuário (se for token de usuário)
      if (validation.type === 'user' && validation.data.id !== interaction.user.id) {
        throw new Error('Este token não pertence à sua conta Discord!');
      }

      const db = readDB();
      db[interaction.user.id] = {
        token: tokenValue,
        type: validation.type,
        username: validation.data.username,
        discriminator: validation.data.discriminator,
        userId: validation.data.id,
        addedAt: new Date().toISOString(),
        lastValidated: new Date().toISOString()
      };

      if (!writeDB(db)) {
        throw new Error('Erro ao salvar token no banco de dados.');
      }

      console.log(`✅ Token vinculado para ${interaction.user.tag} (Tipo: ${validation.type})`);

      const successEmbed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle('✅ Token Vinculado com Sucesso!')
        .setDescription(`**Conta validada:** ${validation.data.username}#${validation.data.discriminator}`)
        .addFields(
          { name: '🆔 ID da Conta', value: validation.data.id, inline: true },
          { name: '🔐 Tipo', value: validation.type === 'user' ? 'Token de Usuário' : 'Token de Bot', inline: true },
          { name: '⏱️ Velocidade', value: '1 msg/3 segundos', inline: true },
          { name: '✅ Status', value: 'Pronto para uso', inline: false },
          { name: '🎯 Próximo passo', value: 'Agora você pode usar o **CL DM**', inline: false }
        )
        .setFooter({ text: 'Token armazenado com segurança' });

      await interaction.reply({ embeds: [successEmbed], ephemeral: true });

    } catch (error) {
      console.error('❌ Erro no handleModal:', error);
      
      const helpEmbed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle('❌ Falha na Validação do Token')
        .setDescription(`**Erro:** ${error.message}`)
        .addFields(
          { name: '💡 Seu token parece correto?', value: 
            'Tente estas soluções:\n\n' +
            '• **Token pode estar expirado** - Gere um novo token\n' +
            '• **Conta com 2FA** - Use token que começa com `mfa.`\n' +
            '• **Problema temporário** - Tente novamente em alguns minutos'
          },
          { name: '🔒 Medidas de segurança:', value: 
            '• **Troque sua senha** após usar este sistema\n' +
            '• **Revogue tokens** antigos nas configurações do Discord\n' +
            '• **Ative 2FA** para maior segurança'
          }
        )
        .setFooter({ text: 'Em caso de dúvidas, contate o suporte' });

      await interaction.reply({ embeds: [helpEmbed], ephemeral: true });
    }
  },

  async resetToken(interaction) {
    try {
      console.log(`🔧 Usuário ${interaction.user.tag} solicitou RESET TOKEN`);
      
      const db = readDB();
      if (!db[interaction.user.id]) {
        return await interaction.reply({ 
          content: 'ℹ️ Nenhum token vinculado encontrado para sua conta.', 
          ephemeral: true 
        });
      }

      const userData = db[interaction.user.id];

      const confirmEmbed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle('⚠️ Confirmar Remoção do Token')
        .setDescription(`**Você está prestes a remover seu token vinculado.**\n\n` +
                       `**Conta vinculada:** ${userData.username}#${userData.discriminator}\n` +
                       `**Vinculado em:** ${new Date(userData.addedAt).toLocaleString('pt-BR')}\n\n` +
                       '**Digite **CONFIRMAR** para remover ou **CANCELAR** para abortar.**')
        .setFooter({ text: 'Você tem 15 segundos para confirmar' });

      await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });

      const filter = m => m.author.id === interaction.user.id;
      const collector = interaction.channel.createMessageCollector({ 
        filter, 
        time: 15000, 
        max: 1 
      });

      collector.on('collect', async m => {
        await m.delete().catch(() => {});
        
        if (m.content.toUpperCase() === 'CONFIRMAR') {
          delete db[interaction.user.id];
          if (writeDB(db)) {
            console.log(`✅ Token removido para ${interaction.user.tag}`);
            await interaction.followUp({ 
              content: '✅ Token removido com sucesso!', 
              ephemeral: true 
            });
          } else {
            await interaction.followUp({ 
              content: '❌ Erro ao remover token do banco de dados.', 
              ephemeral: true 
            });
          }
        } else {
          await interaction.followUp({ 
            content: '❌ Remoção cancelada.', 
            ephemeral: true 
          });
        }
      });

      collector.on('end', (collected) => {
        if (collected.size === 0) {
          interaction.followUp({ 
            content: '⏳ Tempo esgotado. Remoção cancelada.', 
            ephemeral: true 
          });
        }
      });

    } catch (error) {
      console.error('❌ Erro no resetToken:', error);
      await interaction.reply({ 
        content: '❌ Erro ao processar remoção do token. Tente novamente.', 
        ephemeral: true 
      });
    }
  },

  hasToken(userId) {
    const db = readDB();
    return !!db[userId];
  },

  getUserToken(userId) {
    const db = readDB();
    return db[userId] ? db[userId].token : null;
  }
};