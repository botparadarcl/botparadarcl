const fs = require('fs');
const path = require('path');
const usedPath = path.join(__dirname, 'usedOnce.json');
const addToken = require('./add_token.js');

function readUsed() {
  if (!fs.existsSync(usedPath)) return {};
  return JSON.parse(fs.readFileSync(usedPath, 'utf8'));
}

function writeUsed(data) {
  fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
}

// Função para garantir que o estado seja resetado
function resetUserState(userId) {
  const used = readUsed();
  if (used.inProgress && used.user === userId) {
    used.inProgress = false;
    delete used.user;
    delete used.startTime;
    writeUsed(used);
    console.log(`✅ Estado resetado para o usuário: ${userId}`);
  }
}

class PrivateMessageDeleter {
    constructor(userToken, userId) {
        this.options = {
            authToken: userToken,
            deleteDelay: 3000,
            maxAttempts: 3
        };
        this.userId = userId;
        this.state = {
            running: false,
            deletedCount: 0,
            failedCount: 0,
            totalMessages: 0,
            currentBatch: 0
        };
    }

    async deletePrivateMessages(targetUserId) {
        if (this.state.running) {
            throw new Error('Já está em execução!');
        }

        this.state.running = true;
        this.state.deletedCount = 0;
        this.state.failedCount = 0;
        this.state.totalMessages = 0;
        this.state.currentBatch = 0;

        try {
            console.log(`🔧 Iniciando exclusão para o usuário: ${targetUserId}`);
            
            const dmChannel = await this.findOrCreateDMChannel(targetUserId);
            if (!dmChannel) {
                throw new Error(`Não foi possível acessar o DM com: ${targetUserId}`);
            }

            console.log(`✅ Canal DM acessado: ${dmChannel.id}`);
            await this.fetchAndDeleteMessages(dmChannel.id);

            // GARANTIR QUE OS DADOS ESTEJAM CORRETOS
            const result = {
                success: this.state.deletedCount > 0 || this.state.failedCount === 0,
                deleted: this.state.deletedCount,
                failed: this.state.failedCount,
                total: this.state.totalMessages,
                batches: this.state.currentBatch
            };

            console.log('📊 Resultado final:', result);
            return result;

        } catch (error) {
            console.error('❌ Erro no processo:', error);
            
            // RETORNAR RESULTADO MESMO COM ERRO
            const result = {
                success: false,
                error: error.message,
                deleted: this.state.deletedCount,
                failed: this.state.failedCount,
                batches: this.state.currentBatch
            };
            
            return result;
        } finally {
            this.state.running = false;
            console.log('🏁 Processo finalizado');
        }
    }

    async findOrCreateDMChannel(targetUserId) {
        try {
            const response = await fetch('https://discord.com/api/v9/users/@me/channels', {
                method: 'POST',
                headers: {
                    'Authorization': this.options.authToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    recipient_id: targetUserId
                })
            });

            if (response.ok) {
                return await response.json();
            } else if (response.status === 400) {
                // Tentar buscar canal existente
                const channelsResponse = await fetch('https://discord.com/api/v9/users/@me/channels', {
                    headers: {
                        'Authorization': this.options.authToken,
                        'Content-Type': 'application/json'
                    }
                });

                if (channelsResponse.ok) {
                    const channels = await channelsResponse.json();
                    return channels.find(channel => 
                        channel.type === 1 &&
                        channel.recipients?.some(recipient => recipient.id === targetUserId)
                    );
                }
                throw new Error(`Canal DM não encontrado: ${response.status}`);
            } else {
                throw new Error(`Erro ao acessar DM: ${response.status}`);
            }
        } catch (error) {
            console.error('❌ Erro no canal DM:', error);
            throw error;
        }
    }

    async fetchAndDeleteMessages(channelId) {
        let beforeMessageId = null;
        let hasMoreMessages = true;
        const startTime = Date.now();

        try {
            while (hasMoreMessages && this.state.running) {
                try {
                    this.state.currentBatch++;
                    console.log(`📦 Processando lote ${this.state.currentBatch}...`);

                    const messages = await this.fetchMessages(channelId, beforeMessageId);
                    
                    if (messages.length === 0) {
                        console.log('✅ Fim das mensagens alcançado');
                        hasMoreMessages = false;
                        continue;
                    }

                    const userMessages = messages.filter(msg => msg.author.id === this.userId);
                    this.state.totalMessages += userMessages.length;

                    console.log(`👤 ${userMessages.length} mensagens do usuário no lote`);

                    if (userMessages.length === 0) {
                        console.log('⏭️ Nenhuma mensagem do usuário neste lote, pulando...');
                        beforeMessageId = messages[messages.length - 1]?.id;
                        continue;
                    }

                    // Deletar mensagens em sequência
                    for (const message of userMessages) {
                        if (!this.state.running) {
                            console.log('⏹️ Processo interrompido pelo usuário');
                            return;
                        }
                        
                        const success = await this.deleteSingleMessage(message, channelId);
                        if (success) {
                            this.state.deletedCount++;
                            console.log(`✅ [${this.state.deletedCount}] Mensagem deletada`);
                        } else {
                            this.state.failedCount++;
                            console.log(`❌ Falha na mensagem`);
                        }
                        
                        // Delay de 3 segundos entre mensagens
                        await this.delay(this.options.deleteDelay);
                    }

                    beforeMessageId = messages[messages.length - 1]?.id;

                } catch (error) {
                    console.error('💥 Erro no processamento do lote:', error);
                    hasMoreMessages = false;
                    throw error;
                }
            }

            const totalTime = (Date.now() - startTime) / 1000;
            console.log(`⏱️ Processo concluído em ${totalTime.toFixed(1)} segundos`);

        } catch (error) {
            console.error('💥 Erro geral no fetchAndDeleteMessages:', error);
            throw error;
        }
    }

    async fetchMessages(channelId, beforeId = null) {
        const params = new URLSearchParams({ limit: '100' });
        if (beforeId) params.append('before', beforeId);

        try {
            const response = await fetch(
                `https://discord.com/api/v9/channels/${channelId}/messages?${params}`,
                {
                    headers: {
                        'Authorization': this.options.authToken,
                        'Content-Type': 'application/json'
                    }
                }
            );

            if (response.ok) {
                return await response.json();
            } else if (response.status === 429) {
                const rateLimitData = await response.json();
                const retryAfter = rateLimitData.retry_after * 1000;
                console.log(`🚦 Rate limit atingido. Esperando ${retryAfter}ms...`);
                await this.delay(retryAfter);
                return await this.fetchMessages(channelId, beforeId);
            } else {
                throw new Error(`Erro API: ${response.status}`);
            }
        } catch (error) {
            console.error('❌ Erro na requisição de mensagens:', error);
            throw error;
        }
    }

    async deleteSingleMessage(message, channelId) {
        let attempt = 0;
        
        while (attempt < this.options.maxAttempts) {
            try {
                const response = await fetch(
                    `https://discord.com/api/v9/channels/${channelId}/messages/${message.id}`,
                    {
                        method: 'DELETE',
                        headers: {
                            'Authorization': this.options.authToken,
                            'Content-Type': 'application/json'
                        }
                    }
                );

                if (response.ok) {
                    return true;
                } else if (response.status === 429) {
                    const rateLimitData = await response.json();
                    const retryAfter = rateLimitData.retry_after * 1000;
                    console.log(`🚦 Rate limit na deleção. Esperando ${retryAfter}ms...`);
                    await this.delay(retryAfter);
                    attempt++;
                } else if (response.status === 404) {
                    console.log('ℹ️ Mensagem já deletada ou não encontrada');
                    return false;
                } else {
                    console.log(`⚠️ Erro ${response.status} na deleção, tentativa ${attempt + 1}`);
                    attempt++;
                }
            } catch (error) {
                console.error('💥 Erro na tentativa de deleção:', error);
                attempt++;
            }
        }
        
        console.log(`❌ Falha após ${this.options.maxAttempts} tentativas`);
        return false;
    }

    stop() {
        this.state.running = false;
        console.log('⏹️ Processo de deleção interrompido');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

module.exports = {
    async start(interaction, client) {
        // Resetar estado anterior do usuário (IMPORTANTE)
        resetUserState(interaction.user.id);

        if (!addToken.hasToken(interaction.user.id)) {
            return interaction.reply({
                content: '⚠️ **Você precisa vincular seu token primeiro!**\n\n' +
                        '1. Clique em **"ADD TOKEN"**\n' +
                        '2. Cole o token da sua conta Discord\n' +
                        '3. Use **"CL DM"** após vincular',
                ephemeral: true
            });
        }

        const used = readUsed();
        if (used.inProgress) {
            return interaction.reply({
                content: '⏳ Uma limpeza já está em andamento. Aguarde o término.',
                ephemeral: true
            });
        }

        // CONFIRMAÇÃO - SEMPRE PEDIR ID NOVO
        const confirmEmbed = {
            color: 0xff0000,
            title: '⚠️ **CONFIRMAÇÃO DE EXCLUSÃO**',
            description: '**ISSO VAI DELETAR SUAS MENSAGENS PERMANENTEMENTE!**\n\n' +
                        '✅ **DELETA MENSAGENS REAIS**\n' +
                        '✅ **AÇÃO IRREVERSÍVEL**\n' +
                        '✅ **APENAS SUAS MENSAGENS**\n' +
                        '⏱️ **VELOCIDADE:** 1 mensagem a cada 3 segundos\n\n' +
                        '🔒 **RECOMENDAÇÃO DE SEGURANÇA:**\n' +
                        '• **Troque sua senha** após usar este sistema\n' +
                        '• **Revogue tokens** antigos nas configurações\n' +
                        '• **Ative 2FA** para proteção extra\n\n' +
                        'Digite **CONFIRMAR** para prosseguir ou **CANCELAR** para abortar.',
            footer: { text: 'Você tem 30 segundos para confirmar' }
        };

        await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });

        const filter = m => m.author.id === interaction.user.id;
        const collector = interaction.channel.createMessageCollector({ 
            filter, 
            time: 30000, 
            max: 1 
        });

        collector.on('collect', async m => {
            await m.delete().catch(() => {});

            if (m.content.toUpperCase() !== 'CONFIRMAR') {
                resetUserState(interaction.user.id);
                return interaction.followUp({ 
                    content: '❌ Processo cancelado.', 
                    ephemeral: true 
                });
            }

            // Marcar como em progresso
            used.inProgress = true;
            used.user = interaction.user.id;
            used.startTime = new Date().toISOString();
            writeUsed(used);

            // SEMPRE PEDIR ID NOVO - MESMO QUE SEJA O MESMO USUÁRIO
            await interaction.followUp({ 
                content: '🔍 **Digite o ID do usuário alvo:**\n\n' +
                        'Envie o **ID numérico** da pessoa cujas DMs você deseja limpar.\n' +
                        '**Exemplo:** `123456789012345678`\n\n' +
                        '💡 **Como obter o ID:**\n' +
                        '• Ative o Modo Desenvolvedor nas configurações do Discord\n' +
                        '• Clique com botão direito no usuário → "Copiar ID"',
                ephemeral: true 
            });

            const idCollector = interaction.channel.createMessageCollector({ 
                filter, 
                time: 60000, 
                max: 1 
            });

            idCollector.on('collect', async targetMessage => {
                await targetMessage.delete().catch(() => {});
                const targetUserId = targetMessage.content.trim();

                // Validação do ID
                if (!targetUserId.match(/^\d{17,20}$/)) {
                    resetUserState(interaction.user.id);
                    return interaction.followUp({ 
                        content: '❌ **ID inválido!**\n\n' +
                                'O ID deve conter **17-20 dígitos numéricos**.\n' +
                                '**Exemplo correto:** `123456789012345678`\n\n' +
                                '🔍 **Como obter o ID correto:**\n' +
                                '1. Vá em Configurações → Avançado → Ativar Modo Desenvolvedor\n' +
                                '2. Clique com botão direito no usuário\n' +
                                '3. Selecione "Copiar ID"',
                        ephemeral: true 
                    });
                }

                // INICIAR PROCESSO
                const startTime = Date.now();
                const progressMessage = await interaction.followUp({ 
                    content: '🔄 **Iniciando processo de exclusão...**\n\n' +
                            '⏱️ **Velocidade:** 1 mensagem a cada 3 segundos\n' +
                            '📊 **Status:** Preparando...\n' +
                            '⚠️ **Não feche esta janela**',
                    ephemeral: true 
                });

                try {
                    const userToken = addToken.getUserToken(interaction.user.id);
                    const deleter = new PrivateMessageDeleter(userToken, interaction.user.id);
                    
                    // Sistema de progresso em tempo real
                    let lastUpdate = 0;
                    let progressUpdater;

                    const updateProgress = async () => {
                        const now = Date.now();
                        if (now - lastUpdate < 2000) return;
                        
                        lastUpdate = now;
                        try {
                            const elapsed = Math.floor((now - startTime) / 1000);
                            const rate = deleter.state.deletedCount > 0 ? (elapsed / deleter.state.deletedCount).toFixed(1) : '0';
                            
                            await progressMessage.edit({
                                content: `📊 **Progresso em Tempo Real**\n\n` +
                                        `✅ **Deletadas:** ${deleter.state.deletedCount} mensagens\n` +
                                        `❌ **Falhas:** ${deleter.state.failedCount}\n` +
                                        `🔍 **Total estimado:** ${deleter.state.totalMessages}\n` +
                                        `📦 **Lotes processados:** ${deleter.state.currentBatch}\n` +
                                        `⏱️ **Tempo decorrido:** ${elapsed} segundos\n` +
                                        `⚡ **Velocidade:** ${rate}s por mensagem\n\n` +
                                        `🔄 **Processando...**`
                            });
                        } catch (error) {
                            console.log('ℹ️ Mensagem de progresso já atualizada');
                        }
                    };

                    // Atualizar progresso a cada segundo
                    progressUpdater = setInterval(updateProgress, 1000);

                    // Executar a exclusão
                    console.log('🔄 Iniciando processo de deleção...');
                    const result = await deleter.deletePrivateMessages(targetUserId);
                    console.log('✅ Processo de deleção concluído:', result);

                    // PARAR ATUALIZAÇÃO DE PROGRESSO
                    clearInterval(progressUpdater);
                    
                    // LIMPAR ESTADO APÓS CONCLUSÃO
                    resetUserState(interaction.user.id);

                    const totalTime = Math.floor((Date.now() - startTime) / 1000);
                    console.log(`⏱️ Tempo total do processo: ${totalTime} segundos`);

                    // Enviar logs
                    await this.sendLogs(client, interaction, targetUserId, result, totalTime);

                    // RESULTADO FINAL - MENSAGEM CORRIGIDA
                    let finalMessage = '';
                    
                    if (result.success) {
                        finalMessage = `✅ **EXCLUSÃO CONCLUÍDA COM SUCESSO!**\n\n` +
                                      `🗑️ **Mensagens deletadas:** ${result.deleted}\n` +
                                      `❌ **Falhas:** ${result.failed}\n` +
                                      `📊 **Total processado:** ${result.total} mensagens\n` +
                                      `📦 **Lotes processados:** ${result.batches}\n` +
                                      `⏱️ **Tempo total:** ${totalTime} segundos\n`;
                        
                        if (result.deleted > 0) {
                            finalMessage += `⚡ **Velocidade média:** ${(result.deleted / totalTime).toFixed(1)} msg/segundo\n\n`;
                        }
                        
                        finalMessage += `⚠️ **Ação irreversível concluída**\n\n` +
                                       `🔒 **MEDIDA DE SEGURANÇA RECOMENDADA:**\n` +
                                       `• **Troque a senha da sua conta Discord**\n` +
                                       `• **Revogue tokens antigos** nas configurações\n` +
                                       `• **Ative a autenticação de dois fatores (2FA)**`;
                    } else {
                        finalMessage = `❌ **ERRO NA EXCLUSÃO**\n\n` +
                                      `🗑️ **Mensagens deletadas:** ${result.deleted}\n` +
                                      `❌ **Falhas:** ${result.failed}\n` +
                                      `📦 **Lotes processados:** ${result.batches}\n\n` +
                                      `💡 **Erro:** ${result.error}\n\n` +
                                      `🔧 **Solução:** Tente novamente ou contate o suporte.\n\n` +
                                      `🔒 **Dica de segurança:** Considere trocar sua senha.`;
                    }

                    // EDITAR A MENSAGEM FINAL - CORREÇÃO IMPORTANTE
                    try {
                        await progressMessage.edit({
                            content: finalMessage
                        });
                        console.log('✅ Mensagem final enviada com sucesso');
                    } catch (editError) {
                        console.error('❌ Erro ao editar mensagem final:', editError);
                        // Tentar enviar como nova mensagem se a edição falhar
                        await interaction.followUp({
                            content: finalMessage,
                            ephemeral: true
                        });
                    }

                } catch (error) {
                    resetUserState(interaction.user.id);
                    console.error('💥 Erro crítico no processo:', error);
                    
                    // MENSAGEM DE ERRO CORRIGIDA
                    try {
                        await progressMessage.edit({
                            content: `💥 **ERRO CRÍTICO**\n\n` +
                                    `**Mensagem:** ${error.message}\n\n` +
                                    `🔄 **Sistema reiniciado.** Tente novamente.\n\n` +
                                    `🔒 **Por segurança, troque sua senha.**`
                        });
                    } catch (editError) {
                        await interaction.followUp({
                            content: `💥 **ERRO CRÍTICO**\n\n${error.message}`,
                            ephemeral: true
                        });
                    }
                }
            });

            idCollector.on('end', (collected) => {
                if (collected.size === 0) {
                    resetUserState(interaction.user.id);
                    interaction.followUp({ 
                        content: '❌ Tempo esgotado para enviar o ID. Processo cancelado.', 
                        ephemeral: true 
                    });
                }
            });
        });

        collector.on('end', (collected) => {
            if (collected.size === 0) {
                resetUserState(interaction.user.id);
                interaction.followUp({ 
                    content: '❌ Confirmação não recebida. Processo cancelado.', 
                    ephemeral: true 
                });
            }
        });
    },

    async sendLogs(client, interaction, targetUserId, result, totalTime) {
        try {
            const dbPath = path.join(__dirname, 'userKeys.json');
            if (fs.existsSync(dbPath)) {
                const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                if (db.logsChannel) {
                    const ch = client.channels.cache.get(db.logsChannel);
                    if (ch) {
                        const logEmbed = {
                            color: result.success ? 0x00ff00 : 0xff0000,
                            title: result.success ? '✅ Limpeza Concluída' : '❌ Limpeza com Erros',
                            fields: [
                                { name: 'Usuário', value: `<@${interaction.user.id}>`, inline: true },
                                { name: 'Alvo', value: targetUserId, inline: true },
                                { name: 'Deletadas', value: result.deleted.toString(), inline: true },
                                { name: 'Falhas', value: result.failed.toString(), inline: true },
                                { name: 'Tempo', value: `${totalTime}s`, inline: true },
                                { name: 'Lotes', value: result.batches.toString(), inline: true }
                            ],
                            timestamp: new Date(),
                            footer: { text: `ID do usuário: ${interaction.user.id}` }
                        };
                        
                        if (result.error) {
                            logEmbed.fields.push({ 
                                name: 'Erro', 
                                value: result.error.length > 100 ? result.error.substring(0, 100) + '...' : result.error 
                            });
                        }
                        
                        await ch.send({ embeds: [logEmbed] });
                    }
                }
            }
        } catch (error) {
            console.error('❌ Erro ao enviar logs:', error);
        }
    }
};