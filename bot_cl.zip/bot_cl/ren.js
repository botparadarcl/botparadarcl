const fs = require('fs');
const path = require('path');
const cooldownPath = path.join(__dirname, 'renCooldown.json');
const usedPath = path.join(__dirname, 'usedOnce.json');
const tokensPath = path.join(__dirname, 'userTokens.json');

// Garantir que os arquivos existam
function ensureFiles() {
    if (!fs.existsSync(cooldownPath)) {
        fs.writeFileSync(cooldownPath, JSON.stringify({}));
    }
    if (!fs.existsSync(usedPath)) {
        fs.writeFileSync(usedPath, JSON.stringify({}));
    }
    if (!fs.existsSync(tokensPath)) {
        fs.writeFileSync(tokensPath, JSON.stringify({}));
    }
}

function readCooldown() {
    ensureFiles();
    try {
        const data = fs.readFileSync(cooldownPath, 'utf8');
        return data ? JSON.parse(data) : {};
    } catch (error) {
        console.error('❌ Erro ao ler cooldown:', error);
        return {};
    }
}

function writeCooldown(data) {
    try {
        fs.writeFileSync(cooldownPath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('❌ Erro ao salvar cooldown:', error);
        return false;
    }
}

function readUsed() {
    ensureFiles();
    try {
        const data = fs.readFileSync(usedPath, 'utf8');
        return data ? JSON.parse(data) : {};
    } catch (error) {
        console.error('❌ Erro ao ler used:', error);
        return {};
    }
}

function writeUsed(data) {
    try {
        fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('❌ Erro ao salvar used:', error);
        return false;
    }
}

function readTokens() {
    ensureFiles();
    try {
        const data = fs.readFileSync(tokensPath, 'utf8');
        return data ? JSON.parse(data) : {};
    } catch (error) {
        console.error('❌ Erro ao ler tokens:', error);
        return {};
    }
}

function writeTokens(data) {
    try {
        fs.writeFileSync(tokensPath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('❌ Erro ao salvar tokens:', error);
        return false;
    }
}

async function doReset(interaction, emergency = false) {
    try {
        // Backup dos tokens antes de resetar
        const tokensBackup = readTokens();
        
        // Resetar todos os estados
        writeUsed({});
        writeCooldown({});
        
        // Manter apenas os tokens se for reinício normal
        if (!emergency) {
            writeTokens(tokensBackup);
        } else {
            // Emergencial: limpar tudo
            writeTokens({});
        }
        
        console.log(`✅ Sistema reiniciado por ${interaction.user.tag} (emergency: ${emergency})`);
        console.log(`📊 Tokens mantidos: ${Object.keys(tokensBackup).length}`);
        
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({
                content: `♻️ ${interaction.user} reiniciou o sistema CL DM.\n` +
                        `✅ **Todos os processos foram interrompidos**\n` +
                        `🔄 **Estados resetados com sucesso**\n` +
                        `${emergency ? '🔴 **MODO EMERGENCIAL: Tokens também foram limpos**' : '🟢 Tokens foram preservados'}`,
                ephemeral: true
            });
        } else {
            await interaction.reply({
                content: `♻️ ${interaction.user} reiniciou o sistema CL DM.\n` +
                        `✅ **Todos os processos foram interrompidos**\n` +
                        `🔄 **Estados resetados com sucesso**\n` +
                        `${emergency ? '🔴 **MODO EMERGENCIAL: Tokens também foram limpos**' : '🟢 Tokens foram preservados'}`,
                ephemeral: true
            });
        }
        
    } catch (error) {
        console.error('❌ Erro no doReset:', error);
        
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({
                content: '❌ Erro ao reiniciar o sistema. Tente novamente.',
                ephemeral: true
            });
        } else {
            await interaction.reply({
                content: '❌ Erro ao reiniciar o sistema. Tente novamente.',
                ephemeral: true
            });
        }
    }
}

module.exports = {
    async resetAll(interaction, emergency = false) {
        try {
            console.log(`🔧 Solicitação de reinício por ${interaction.user.tag} (emergency: ${emergency})`);
            
            if (!interaction.member.permissions.has('Administrator')) {
                return interaction.reply({ 
                    content: '🚫 Apenas administradores podem usar este comando.', 
                    ephemeral: true 
                });
            }

            if (!emergency) {
                // Reinício normal com cooldown
                const cd = readCooldown();
                const last = cd.lastRestart || 0;
                const now = Date.now();
                const twoHours = 2 * 60 * 60 * 1000;

                if (now - last < twoHours) {
                    const remain = Math.ceil((twoHours - (now - last)) / 60000);
                    return interaction.reply({ 
                        content: `⏳ Reinício normal disponível em **${remain} minutos**.`, 
                        ephemeral: true 
                    });
                }
                
                // Atualizar cooldown
                cd.lastRestart = now;
                if (writeCooldown(cd)) {
                    await interaction.reply({ 
                        content: '🔄 Reiniciando sistema CL DM...', 
                        ephemeral: true 
                    });
                    return await doReset(interaction, false);
                } else {
                    throw new Error('Falha ao atualizar cooldown');
                }
            }

            // Reinício emergencial - sem cooldown, com senha
            await interaction.reply({
                content: '🔴 **REINÍCIO EMERGENCIAL**\n\n' +
                        '⚠️ **ISSO VAI LIMPAR TODOS OS TOKENS ARMAZENADOS!**\n\n' +
                        'Digite a senha para confirmar (30 segundos):\n' +
                        '```botparadarcl```',
                ephemeral: true
            });

            const filter = m => m.author.id === interaction.user.id;
            const collector = interaction.channel.createMessageCollector({ 
                filter, 
                time: 30000, 
                max: 1 
            });
            
            collector.on('collect', async m => {
                try {
                    await m.delete().catch(() => {});
                    
                    if (m.content.trim() !== 'botparadarcl') {
                        return await interaction.followUp({ 
                            content: '❌ Senha incorreta. Reinício emergencial cancelado.', 
                            ephemeral: true 
                        });
                    }
                    
                    await interaction.followUp({
                        content: '✅ Senha confirmada. Reiniciando sistema...',
                        ephemeral: true
                    });
                    
                    await doReset(interaction, true);
                    
                } catch (error) {
                    console.error('❌ Erro no coletor:', error);
                    await interaction.followUp({
                        content: '❌ Erro durante o reinício emergencial.',
                        ephemeral: true
                    });
                }
            });

            collector.on('end', async (collected) => {
                if (collected.size === 0) {
                    await interaction.followUp({ 
                        content: '⏳ Tempo esgotado. Reinício emergencial cancelado.', 
                        ephemeral: true 
                    });
                }
            });

        } catch (error) {
            console.error('❌ Erro no resetAll:', error);
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ 
                    content: '❌ Erro ao processar reinício. Tente novamente.', 
                    ephemeral: true 
                });
            } else {
                await interaction.reply({ 
                    content: '❌ Erro ao processar reinício. Tente novamente.', 
                    ephemeral: true 
                });
            }
        }
    },
    
    // Função para verificar o estado atual do sistema
    getSystemStatus() {
        const used = readUsed();
        const tokens = readTokens();
        const cooldown = readCooldown();
        
        return {
            inProgress: used.inProgress || false,
            currentUser: used.user || null,
            startTime: used.startTime || null,
            totalTokens: Object.keys(tokens).length,
            lastRestart: cooldown.lastRestart || null
        };
    }
};