const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

async function createCLMessage() {
    const clEmbed = new EmbedBuilder()
        .setColor('#2ecc71')
        .setTitle('🎯 Canal CL – Sistema de Limpeza de Mensagens')
        .setDescription(
            '**🔐 SISTEMA COM TOKEN PESSOAL**\n\n' +
            'Utilize este sistema para deletar suas mensagens privadas de forma segura e controlada.\n\n' +
            '**📋 FUNCIONALIDADES PRINCIPAIS:**\n' +
            '• **ADD TOKEN** – Vincule o token da sua conta\n' +
            '• **CL DM** – Deleta suas mensagens privadas\n' +
            '• **RESET TOKEN** – Remove seu token vinculado\n\n' +
            '**🛡️ SEGURANÇA:**\n' +
            '• ⏱️ Velocidade controlada: 1 mensagem/3 segundos\n' +
            '• 🔐 Token criptografado no armazenamento\n' +
            '• 📊 Logs de todas as atividades\n' +
            '• 🔒 Recomendado: Troque a senha após o uso'
        )
        .setFooter({ 
            text: 'Sistema de limpeza com ferramentas de manutenção',
            iconURL: 'https://cdn.discordapp.com/emojis/998805272468660304.png'
        })
        .setTimestamp();

    // Botões principais
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('cl_dm')
            .setLabel('🗑️ CL DM')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('⚠️'),
        new ButtonBuilder()
            .setCustomId('cl_addtoken')
            .setLabel('🔐 ADD TOKEN')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('🔑')
    );
    
    // Botões secundários
    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('cl_resettoken')
            .setLabel('🔄 RESET TOKEN')
            .setStyle(ButtonStyle.Secondary)
            .setEmoji('♻️'),
        new ButtonBuilder()
            .setCustomId('cl_comousar')
            .setLabel('📖 Como Usar')
            .setStyle(ButtonStyle.Success)
            .setEmoji('ℹ️')
    );

    // REMOVIDA A ROW3 - Botões de administração (REN)
    // const row3 = new ActionRowBuilder().addComponents(
    //     new ButtonBuilder()
    //         .setCustomId('ren_global')
    //         .setLabel('🔄 Reiniciar Sistema')
    //         .setStyle(ButtonStyle.Primary)
    //         .setEmoji('🔧'),
    //     new ButtonBuilder()
    //         .setCustomId('ren_emergency')
    //         .setLabel('🚨 Emergencial')
    //         .setStyle(ButtonStyle.Danger)
    //         .setEmoji('⚠️')
    // );

    return { 
        embeds: [clEmbed], 
        components: [row1, row2] // REMOVIDA A ROW3 DA LISTA
    };
}

module.exports = { createCLMessage };