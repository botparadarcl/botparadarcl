const fs = require('fs');
const path = require('path');
const usedPath = path.join(__dirname, 'usedOnce.json');
const addToken = require('./add_token.js');
const { EmbedBuilder } = require('discord.js');

function readUsed() {
    if (!fs.existsSync(usedPath)) return {};
    return JSON.parse(fs.readFileSync(usedPath, 'utf8'));
}

function writeUsed(data) {
    fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
}

// Função para garantir que o estado seja resetado
function resetUserState(userId) {
    const used = readUsed();
    if (used.inProgress && used.user === userId) {
        used.inProgress = false;
        delete used.user;
        delete used.startTime;
        writeUsed(used);
        console.log(`Estado resetado para o usuario: ${userId}`);
    }
}

class PrivateMessageDeleter {
    constructor(userToken, userId) {
        this.options = {
            authToken: userToken,
            deleteDelay: 1000,
            maxAttempts: 3
        };
        this.userId = userId;
        this.state = {
            running: false,
            deletedCount: 0,
            failedCount: 0,
            totalMessages: 0,
            currentBatch: 0
        };
    }

    async deletePrivateMessages(targetUserId) {
        if (this.state.running) {
            throw new Error('Ja esta em execucao!');
        }

        this.state.running = true;
        this.state.deletedCount = 0;
        this.state.failedCount = 0;
        this.state.totalMessages = 0;
        this.state.currentBatch = 0;

        try {
            console.log(`Iniciando exclusão para o usuario: ${targetUserId}`);

            const dmChannel = await this.findOrCreateDMChannel(targetUserId);
            if (!dmChannel) {
                throw new Error(`Nao foi possivel acessar o DM com: ${targetUserId}`);
            }

            console.log(`Canal DM acessado: ${dmChannel.id}`);
            await this.fetchAndDeleteMessages(dmChannel.id);

            const result = {
                success: this.state.deletedCount > 0 || this.state.failedCount === 0,
                deleted: this.state.deletedCount,
                failed: this.state.failedCount,
                total: this.state.totalMessages,
                batches: this.state.currentBatch
            };

            console.log('Resultado final:', result);
            return result;

        } catch (error) {
            console.error('Erro no processo:', error);

            const result = {
                success: false,
                error: error.message,
                deleted: this.state.deletedCount,
                failed: this.state.failedCount,
                batches: this.state.currentBatch
            };

            return result;
        } finally {
            this.state.running = false;
            console.log('Processo finalizado');
        }
    }

    async findOrCreateDMChannel(targetUserId) {
        try {
            const response = await fetch('https://discord.com/api/v9/users/@me/channels', {
                method: 'POST',
                headers: {
                    'Authorization': this.options.authToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    recipient_id: targetUserId
                })
            });

            if (response.ok) {
                return await response.json();
            } else if (response.status === 400) {
                // DM já existe, buscar na lista de canais
                const channelsResponse = await fetch('https://discord.com/api/v9/users/@me/channels', {
                    headers: {
                        'Authorization': this.options.authToken,
                        'Content-Type': 'application/json'
                    }
                });

                if (channelsResponse.ok) {
                    const channels = await channelsResponse.json();
                    const dmChannel = channels.find(channel =>
                        channel.type === 1 &&
                        channel.recipients?.some(recipient => recipient.id === targetUserId)
                    );

                    if (!dmChannel) {
                        throw new Error('Canal DM nao encontrado na lista de canais');
                    }
                    return dmChannel;
                }
                throw new Error(`Erro ao buscar canais: ${channelsResponse.status}`);
            } else {
                throw new Error(`Erro ao acessar DM: ${response.status}`);
            }
        } catch (error) {
            console.error('Erro no canal DM:', error);
            throw error;
        }
    }

    async fetchAndDeleteMessages(channelId) {
        let beforeMessageId = null;
        let hasMoreMessages = true;
        const startTime = Date.now();

        try {
            while (hasMoreMessages && this.state.running) {
                try {
                    this.state.currentBatch++;
                    console.log(`Processando lote ${this.state.currentBatch}...`);

                    const messages = await this.fetchMessages(channelId, beforeMessageId);

                    if (messages.length === 0) {
                        console.log('Fim das mensagens alcancado');
                        hasMoreMessages = false;
                        continue;
                    }

                    // CORREÇÃO: Filtrar mensagens do usuário atual
                    const userMessages = messages.filter(msg => msg.author.id === this.userId);
                    this.state.totalMessages += userMessages.length;

                    console.log(`${userMessages.length} mensagens do usuario no lote`);

                    if (userMessages.length === 0) {
                        console.log('Nenhuma mensagem do usuario neste lote, pulando...');
                        beforeMessageId = messages[messages.length - 1]?.id;
                        continue;
                    }

                    // CORREÇÃO: Deletar em ordem reversa para evitar problemas de rate limit
                    for (let i = userMessages.length - 1; i >= 0; i--) {
                        const message = userMessages[i];

                        if (!this.state.running) {
                            console.log('Processo interrompido pelo usuario');
                            return;
                        }

                        const success = await this.deleteSingleMessage(message, channelId);
                        if (success) {
                            this.state.deletedCount++;
                            console.log(`[${this.state.deletedCount}] Mensagem deletada`);
                        } else {
                            this.state.failedCount++;
                            console.log(`Falha na mensagem`);
                        }

                        await this.delay(this.options.deleteDelay);
                    }

                    beforeMessageId = messages[messages.length - 1]?.id;

                } catch (error) {
                    console.error('Erro no processamento do lote:', error);
                    hasMoreMessages = false;
                    throw error;
                }
            }

            const totalTime = (Date.now() - startTime) / 1000;
            console.log(`Processo concluido em ${totalTime.toFixed(1)} segundos`);

        } catch (error) {
            console.error('Erro geral no fetchAndDeleteMessages:', error);
            throw error;
        }
    }

    async fetchMessages(channelId, beforeId = null) {
        const params = new URLSearchParams({ limit: '100' });
        if (beforeId) params.append('before', beforeId);

        try {
            const response = await fetch(
                `https://discord.com/api/v9/channels/${channelId}/messages?${params}`,
                {
                    headers: {
                        'Authorization': this.options.authToken,
                        'Content-Type': 'application/json'
                    }
                }
            );

            if (response.ok) {
                return await response.json();
            } else if (response.status === 429) {
                const rateLimitData = await response.json();
                const retryAfter = rateLimitData.retry_after * 1000;
                console.log(`Rate limit atingido. Esperando ${retryAfter}ms...`);
                await this.delay(retryAfter);
                return await this.fetchMessages(channelId, beforeId);
            } else if (response.status === 403) {
                throw new Error('Sem permissao para acessar este canal');
            } else if (response.status === 404) {
                throw new Error('Canal nao encontrado');
            } else {
                throw new Error(`Erro API: ${response.status}`);
            }
        } catch (error) {
            console.error('Erro na requisicao de mensagens:', error);
            throw error;
        }
    }

    async deleteSingleMessage(message, channelId) {
        let attempt = 0;

        while (attempt < this.options.maxAttempts) {
            try {
                const response = await fetch(
                    `https://discord.com/api/v9/channels/${channelId}/messages/${message.id}`,
                    {
                        method: 'DELETE',
                        headers: {
                            'Authorization': this.options.authToken,
                            'Content-Type': 'application/json'
                        }
                    }
                );

                if (response.ok) {
                    return true;
                } else if (response.status === 429) {
                    const rateLimitData = await response.json();
                    const retryAfter = rateLimitData.retry_after * 1000;
                    console.log(`Rate limit na delecao. Esperando ${retryAfter}ms...`);
                    await this.delay(retryAfter);
                    attempt++;
                } else if (response.status === 404) {
                    console.log('Mensagem ja deletada ou nao encontrada');
                    return false;
                } else if (response.status === 403) {
                    console.log('Sem permissao para deletar esta mensagem');
                    return false;
                } else {
                    console.log(`Erro ${response.status} na delecao, tentativa ${attempt + 1}`);
                    attempt++;
                    await this.delay(1000);
                }
            } catch (error) {
                console.error('Erro na tentativa de delecao:', error);
                attempt++;
                await this.delay(1000);
            }
        }

        console.log(`Falha apos ${this.options.maxAttempts} tentativas`);
        return false;
    }

    stop() {
        this.state.running = false;
        console.log('Processo de delecao interrompido');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

module.exports = {
    async start(interaction, client) {
        resetUserState(interaction.user.id);

        if (!addToken.hasToken(interaction.user.id)) {
            return interaction.reply({
                embeds: [{
                    color: 0xFF0000, // Vermelho para indicar erro
                    title: 'Token não vinculado!',
                    description: 'Você precisa vincular seu token primeiro!',
                    fields: [
                        {
                            name: 'Instruções:',
                            value: '1. Clique em "Token"\n2. Cole o token da sua conta Discord\n3. Use "CL" após vincular',
                        },
                    ],
                    footer: {
                        text: 'Caso tenha alguma dúvida, entre em contato com o suporte.',
                    },
                    timestamp: new Date(),
                }],
                ephemeral: true,
            });
        }

        const used = readUsed();
        if (used.inProgress) {
            return interaction.reply({
                content: 'Uma limpeza ja esta em andamento. Aguarde o termino.',
                ephemeral: true
            });
        }

        // Mensagem simplificada para pedir o ID
        await interaction.reply({
            embeds: [{
                color: 0x0099ff,
                title: 'Digite o ID do usuário',
                description: 'Envie apenas o ID numérico da pessoa.\n\n**Você tem 30 segundos para enviar o ID.**',
                fields: [
                    {
                        name: 'Como obter o ID:',
                        value: '- Ative o **Modo Desenvolvedor** nas configurações\n- Clique com botão direito no usuário → **"Copiar ID"**'
                    }
                ],
                footer: {
                    text: 'Solicitado por ' + interaction.user.username,
                    icon_url: interaction.user.displayAvatarURL()
                }
            }],
            ephemeral: true
        });

        const filter = m => m.author.id === interaction.user.id;
        const idCollector = interaction.channel.createMessageCollector({
            filter,
            time: 60000,
            max: 1
        });

        idCollector.on('collect', async targetMessage => {
            await targetMessage.delete().catch(() => { });
            const targetUserId = targetMessage.content.trim();

            if (!targetUserId.match(/^\d{17,20}$/)) {
                resetUserState(interaction.user.id);
                return interaction.followUp({
                    content: 'ID invalido!\n\n' +
                        'O ID deve conter 17-20 digitos numericos.\n' +
                        'Exemplo correto: 123456789012345678',
                    ephemeral: true
                });
            }

            used.inProgress = true;
            used.user = interaction.user.id;
            used.startTime = new Date().toISOString();
            writeUsed(used);

            const progressEmbed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle('Iniciando processo de exclusão...')
                .setDescription('Nao feche a janela.')
                .setTimestamp();

            const progressMessage = await interaction.followUp({
                embeds: [progressEmbed],
                ephemeral: true
            });

            try {
                const userToken = addToken.getUserToken(interaction.user.id);
                const deleter = new PrivateMessageDeleter(userToken, interaction.user.id);

                let lastUpdate = 0;
                let progressUpdater;

                const updateProgress = async () => {
                    const now = Date.now();
                    if (now - lastUpdate < 2000) return;

                    lastUpdate = now;
                    try {
                        const elapsed = Math.floor((now - startTime) / 1000);
                        const rate = deleter.state.deletedCount > 0 ? (elapsed / deleter.state.deletedCount).toFixed(1) : '0';

                        const progressEmbed = new EmbedBuilder()
                            .setColor(0x0099FF)
                            .setTitle('Processando exclusão...')
                            .setDescription('Nao feche a janela.')
                            .addFields(
                                { name: 'Deletadas', value: deleter.state.deletedCount.toString(), inline: true },
                                { name: 'Falhas', value: deleter.state.failedCount.toString(), inline: true },
                                { name: 'Lotes', value: deleter.state.currentBatch.toString(), inline: true },
                                { name: 'Tempo', value: `${elapsed}s`, inline: true },
                                { name: 'Velocidade', value: `${rate}s/msg`, inline: true }
                            )
                            .setTimestamp();

                        await progressMessage.edit({ embeds: [progressEmbed] });
                    } catch (error) {
                        console.log('Mensagem de progresso ja atualizada');
                    }
                };

                const startTime = Date.now();
                progressUpdater = setInterval(updateProgress, 1000);

                console.log('Iniciando processo de delecao...');
                const result = await deleter.deletePrivateMessages(targetUserId);
                console.log('Processo de delecao concluido:', result);

                clearInterval(progressUpdater);
                resetUserState(interaction.user.id);

                const totalTime = Math.floor((Date.now() - startTime) / 1000);
                console.log(`Tempo total do processo: ${totalTime} segundos`);

                await this.sendLogs(client, interaction, targetUserId, result, totalTime);

                let finalEmbed;

                if (result.success) {
                    finalEmbed = new EmbedBuilder()
                        .setColor(0x00FF00)
                        .setTitle('CL concluído com sucesso.')
                        .setDescription('Altere a senha da sua conta para o token ser resetado. (Tudo por questão de segurança)')
                        .addFields(
                            { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                            { name: 'Falhas', value: result.failed.toString(), inline: true },
                            //{ name: 'Total processado', value: result.total.toString(), inline: true },
                            //{ name: 'Lotes processados', value: result.batches.toString(), inline: true },
                            //{ name: 'Tempo total', value: `${totalTime}s`, inline: true }
                        )
                        .setTimestamp();

                    if (result.deleted > 0) {
                        finalEmbed.addFields({
                            name: 'Velocidade média',
                            value: `${(result.deleted / totalTime).toFixed(1)} msg/segundo`,
                            inline: true
                        });
                    }
                } else {
                    finalEmbed = new EmbedBuilder()
                        .setColor(0xFF0000)
                        .setTitle('Erro na exclusão')
                        .setDescription(`Erro: ${result.error}`)
                        .addFields(
                            { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                            { name: 'Falhas', value: result.failed.toString(), inline: true },
                            { name: 'Lotes processados', value: result.batches.toString(), inline: true }
                        )
                        .setTimestamp();
                }

                try {
                    await progressMessage.edit({ embeds: [finalEmbed] });
                    console.log('Mensagem final enviada com sucesso');
                } catch (editError) {
                    console.error('Erro ao editar mensagem final:', editError);
                    await interaction.followUp({
                        embeds: [finalEmbed],
                        ephemeral: true
                    });
                }

            } catch (error) {
                resetUserState(interaction.user.id);
                console.error('Erro critico no processo:', error);

                const errorEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('Erro critico')
                    .setDescription(`Mensagem: ${error.message}\n\nSistema reiniciado. Tente novamente.`)
                    .setTimestamp();

                try {
                    await progressMessage.edit({ embeds: [errorEmbed] });
                } catch (editError) {
                    await interaction.followUp({
                        embeds: [errorEmbed],
                        ephemeral: true
                    });
                }
            }
        });

        idCollector.on('end', (collected) => {
            if (collected.size === 0) {
                resetUserState(interaction.user.id);
                interaction.followUp({
                    content: 'Tempo esgotado para enviar o ID. Processo cancelado.',
                    ephemeral: true
                });
            }
        });
    },

    async sendLogs(client, interaction, targetUserId, result, totalTime) {
        try {
            const dbPath = path.join(__dirname, 'userKeys.json');
            if (fs.existsSync(dbPath)) {
                const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                if (db.logsChannel) {
                    const ch = client.channels.cache.get(db.logsChannel);
                    if (ch) {
                        const logEmbed = {
                            color: result.success ? 0x00ff00 : 0xff0000,
                            title: result.success ? 'Limpeza Concluida' : 'Limpeza com Erros',
                            fields: [
                                { name: 'Usuario', value: `<@${interaction.user.id}>`, inline: true },
                                // { name: 'Alvo', value: targetUserId, inline: true },  // Comentado conforme solicitado
                                { name: 'Deletadas', value: result.deleted.toString(), inline: true },
                                { name: 'Falhas', value: result.failed.toString(), inline: true },
                                { name: 'Tempo', value: `${totalTime}s`, inline: true },
                                { name: 'Lotes', value: result.batches.toString(), inline: true }
                            ],
                            timestamp: new Date(),
                            footer: { text: '' } // Footer só com horário (timestamp)
                        };
    
                        if (result.error) {
                            logEmbed.fields.push({
                                name: 'Erro',
                                value: result.error.length > 100 ? result.error.substring(0, 100) + '...' : result.error
                            });
                        }
    
                        await ch.send({ embeds: [logEmbed] });
                    }
                }
            }
        } catch (error) {
            console.error('Erro ao enviar logs:', error);
        }
    }
    
};