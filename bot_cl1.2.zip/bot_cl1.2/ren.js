const fs = require('fs');
const path = require('path');
const cooldownPath = path.join(__dirname, 'renCooldown.json');
const usedPath = path.join(__dirname, 'usedOnce.json');
const tokensPath = path.join(__dirname, 'userTokens.json');

// Garantir que os arquivos existam
function ensureFiles() {
  if (!fs.existsSync(cooldownPath)) {
    fs.writeFileSync(cooldownPath, JSON.stringify({}));
  }
  if (!fs.existsSync(usedPath)) {
    fs.writeFileSync(usedPath, JSON.stringify({}));
  }
  if (!fs.existsSync(tokensPath)) {
    fs.writeFileSync(tokensPath, JSON.stringify({}));
  }
}

function readCooldown() {
  ensureFiles();
  try {
    const data = fs.readFileSync(cooldownPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler cooldown:', error);
    return {};
  }
}

function writeCooldown(data) {
  try {
    fs.writeFileSync(cooldownPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar cooldown:', error);
    return false;
  }
}

function readUsed() {
  ensureFiles();
  try {
    const data = fs.readFileSync(usedPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler used:', error);
    return {};
  }
}

function writeUsed(data) {
  try {
    fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar used:', error);
    return false;
  }
}

function readTokens() {
  ensureFiles();
  try {
    const data = fs.readFileSync(tokensPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler tokens:', error);
    return {};
  }
}

function writeTokens(data) {
  try {
    fs.writeFileSync(tokensPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar tokens:', error);
    return false;
  }
}

// CORREÇÃO: Adicionar a função sendRestartNotification
async function sendRestartNotification(client) {
  try {
    const dbPath = path.join(__dirname, 'userKeys.json');
    if (fs.existsSync(dbPath)) {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      if (db.notChannel) {
        const channel = client.channels.cache.get(db.notChannel);
        if (channel) {
          const { EmbedBuilder } = require('discord.js');
          const restartEmbed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setTitle('Reinicio do Sistema')
            .setDescription('Bot reiniciado com sucesso e estou online novamente. Todas as atividades foram encerradas. Pode usar novamente o sistema normalmente.\nPróximo reinício em 1 hora.')
            .setTimestamp();

          await channel.send({ embeds: [restartEmbed] });
        }
      }
    }
  } catch (error) {
    console.error('Erro ao enviar notificacao de reinicio:', error);
  }
}

async function doReset(interaction, emergency = false, autoRestart = false, client = null) {
  try {
    // Backup dos tokens antes de resetar
    const tokensBackup = readTokens();

    // Resetar todos os estados
    writeUsed({});
    writeCooldown({});

    // Manter apenas os tokens se for reinicio normal
    if (!emergency) {
      writeTokens(tokensBackup);
    } else {
      // Emergencial: limpar tudo
      writeTokens({});
    }

    console.log(`Sistema reiniciado por ${interaction?.user?.tag || 'SISTEMA'} (emergency: ${emergency}, auto: ${autoRestart})`);
    console.log(`Tokens mantidos: ${Object.keys(tokensBackup).length}`);

    // CORREÇÃO: Enviar notificação de reinício se for automático e tiver client
    if (autoRestart && client) {
      await sendRestartNotification(client);
    }

    if (interaction && !autoRestart) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: `${interaction.user} reiniciou o sistema CL DM.\n` +
            `Todos os processos foram interrompidos\n` +
            `Estados resetados com sucesso\n` +
            `${emergency ? 'MODO EMERGENCIAL: Tokens tambem foram limpos' : 'Tokens foram preservados'}`,
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: `${interaction.user} reiniciou o sistema CL DM.\n` +
            `Todos os processos foram interrompidos\n` +
            `Estados resetados com sucesso\n` +
            `${emergency ? 'MODO EMERGENCIAL: Tokens tambem foram limpos' : 'Tokens foram preservados'}`,
          ephemeral: true
        });
      }
    }

    return true;

  } catch (error) {
    console.error('Erro no doReset:', error);

    if (interaction && !autoRestart) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: 'Erro ao reiniciar o sistema. Tente novamente.',
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: 'Erro ao reiniciar o sistema. Tente novamente.',
          ephemeral: true
        });
      }
    }
    return false;
  }
}

// Funcao para reinicio automatico
async function autoRestart(client) {
  try {
    console.log('Iniciando reinicio automatico programado...');

    // Ler configuracao do canal de notificacoes
    const dbPath = path.join(__dirname, 'userKeys.json');
    let notChannel = null;
    let logsChannel = null;

    if (fs.existsSync(dbPath)) {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      if (db.notChannel) {
        notChannel = client.channels.cache.get(db.notChannel);
      }
      if (db.logsChannel) {
        logsChannel = client.channels.cache.get(db.logsChannel);
      }
    }

    // Usar canal NOT preferencialmente, senao canal de logs
    const targetChannel = notChannel || logsChannel;

    // Enviar aviso antes do reinicio
    if (targetChannel) {
      await targetChannel.send({
        content: 'AVISO DE REINICIO AUTOMATICO\n\n' +
          'O sistema sera reiniciado automaticamente em 5 minutos, todos os processos em andamento serão cancelados.\n'
      });
    }

    // Aguardar 5 minutos antes do reinicio
    setTimeout(async () => {
      try {
        // CORREÇÃO: Passar o client para o doReset
        await doReset(null, false, true, client);

        // Mensagens de notificação removidas conforme solicitado

        console.log('Reinicio automatico concluido');

        // Programar proximo reinicio
        scheduleNextRestart(client);

      } catch (error) {
        console.error('Erro no reinicio automatico:', error);
        if (targetChannel) {
          await targetChannel.send({
            content: 'ERRO CRITICO NO REINICIO AUTOMATICO\n\n' +
              'Contate um administrador imediatamente.'
          });
        }
      }
    }, 5 * 60 * 1000); // 5 minutos

  } catch (error) {
    console.error('Erro no agendamento do reinicio automatico:', error);
  }
}

// Agendar proximo reinicio
function scheduleNextRestart(client) {
  // 1 hora = 60 * 60 * 1000 milissegundos
  const oneHour = 60 * 60 * 1000;

  setTimeout(() => {
    autoRestart(client);
  }, oneHour);

  console.log(`Proximo reinicio automatico agendado para 1 hora`);
}

module.exports = {
  async resetAll(interaction, emergency = false) {
    try {
      console.log(`Solicitacao de reinicio por ${interaction.user.tag} (emergency: ${emergency})`);

      if (!interaction.member.permissions.has('Administrator')) {
        return interaction.reply({
          content: 'Apenas administradores podem usar este comando.',
          ephemeral: true
        });
      }

      if (!emergency) {
        // CORREÇÃO: Reduzir cooldown de 2 horas para 15 minutos
        const cd = readCooldown();
        const last = cd.lastRestart || 0;
        const now = Date.now();
        const fifteenMinutes = 15 * 60 * 1000; // 15 minutos apenas

        if (now - last < fifteenMinutes) {
          const remain = Math.ceil((fifteenMinutes - (now - last)) / 60000);
          return interaction.reply({
            content: `Reinicio normal disponivel em ${remain} minutos.`,
            ephemeral: true
          });
        }

        // Atualizar cooldown
        cd.lastRestart = now;
        if (writeCooldown(cd)) {
          await interaction.reply({
            content: 'Reiniciando sistema CL DM...',
            ephemeral: true
          });
          return await doReset(interaction, false);
        } else {
          throw new Error('Falha ao atualizar cooldown');
        }
      }

      // Reinicio emergencial - sem cooldown, com senha
      await interaction.reply({
        content: 'REINICIO EMERGENCIAL\n\n' +
          'ISSO VAI LIMPAR TODOS OS TOKENS ARMAZENADOS!\n\n' +
          'Digite a senha para confirmar (30 segundos):\n' +
          'botparadarcl',
        ephemeral: true
      });

      const filter = m => m.author.id === interaction.user.id;
      const collector = interaction.channel.createMessageCollector({
        filter,
        time: 30000,
        max: 1
      });

      collector.on('collect', async m => {
        try {
          await m.delete().catch(() => { });

          if (m.content.trim() !== 'botparadarcl') {
            return await interaction.followUp({
              content: 'Senha incorreta. Reinicio emergencial cancelado.',
              ephemeral: true
            });
          }

          await interaction.followUp({
            content: 'Senha confirmada. Reiniciando sistema...',
            ephemeral: true
          });

          await doReset(interaction, true);

        } catch (error) {
          console.error('Erro no coletor:', error);
          await interaction.followUp({
            content: 'Erro durante o reinicio emergencial.',
            ephemeral: true
          });
        }
      });

      collector.on('end', async (collected) => {
        if (collected.size === 0) {
          await interaction.followUp({
            content: 'Tempo esgotado. Reinicio emergencial cancelado.',
            ephemeral: true
          });
        }
      });

    } catch (error) {
      console.error('Erro no resetAll:', error);

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: 'Erro ao processar reinicio. Tente novamente.',
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: 'Erro ao processar reinicio. Tente novamente.',
          ephemeral: true
        });
      }
    }
  },

  // Funcao para verificar o estado atual do sistema
  getSystemStatus() {
    const used = readUsed();
    const tokens = readTokens();
    const cooldown = readCooldown();

    return {
      inProgress: used.inProgress || false,
      currentUser: used.user || null,
      startTime: used.startTime || null,
      totalTokens: Object.keys(tokens).length,
      lastRestart: cooldown.lastRestart || null
    };
  },

  // Iniciar sistema de reinicio automatico
  startAutoRestart(client) {
    console.log('Iniciando sistema de reinicio automatico (1 hora)');
    scheduleNextRestart(client);
  },

  // CORREÇÃO: Exportar a função sendRestartNotification
  sendRestartNotification
};
