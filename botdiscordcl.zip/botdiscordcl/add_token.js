const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'userTokens.json');

// Garantir que o arquivo existe
if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, '{}');
  console.log('Arquivo userTokens.json criado');
}

function readDB() {
  try {
    if (!fs.existsSync(dbPath)) return {};
    const data = fs.readFileSync(dbPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler database:', error);
    return {};
  }
}

function writeDB(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar database:', error);
    return false;
  }
}

async function validateUserToken(token) {
    try {
        const response = await fetch('https://discord.com/api/v9/users/@me', {
            headers: {
                'Authorization': token,
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            const userData = await response.json();
            return { valid: true, data: userData, type: 'user' };
        } else {
            const responseBot = await fetch('https://discord.com/api/v9/users/@me', {
                headers: {
                    'Authorization': `Bot ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (responseBot.ok) {
                const userData = await responseBot.json();
                return { valid: true, data: userData, type: 'bot' };
            }
            
            throw new Error(`Token invalido (Status: ${response.status})`);
        }
    } catch (error) {
        throw new Error(`Falha na validacao: ${error.message}`);
    }
}

module.exports = {
  async showAddTokenModal(interaction) {
    try {
      console.log(`Usuario ${interaction.user.tag} solicitou ADD TOKEN`);
      
      const db = readDB();
      if (db[interaction.user.id]) {
        const embed = new EmbedBuilder()
          .setColor(0xffa500)
          .setTitle('Token Já Vinculado')
          .setDescription(`Você ja possui um token vinculado a sua conta.\n\n**Usuario:** ${db[interaction.user.id].username}\n**Vinculado em:** ${new Date(db[interaction.user.id].addedAt).toLocaleString('pt-BR')}`)
          .setFooter({ text: 'Use RESET TOKEN se quiser alterar.' });

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      const modal = new ModalBuilder()
        .setCustomId('add_token_modal')
        .setTitle('Vincular Token da Sua Conta')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('user_token')
              .setLabel('Token da sua conta Discord')
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder('Cole o token da SUA CONTA aqui...')
              .setRequired(true)
              .setMinLength(50)
              .setMaxLength(100)
          )
        );

      await interaction.showModal(modal);
      console.log(`Modal aberto para ${interaction.user.tag}`);

    } catch (error) {
      console.error('Erro no showAddTokenModal:', error);
      await interaction.reply({ 
        content: 'Erro ao abrir o modal. Tente novamente.', 
        ephemeral: true 
      });
    }
  },

  async handleModal(interaction) {
    try {
      console.log(`Processando token para ${interaction.user.tag}`);
      
      const tokenValue = interaction.fields.getTextInputValue('user_token').trim();
      
      if (!tokenValue) {
        return await interaction.reply({ 
          content: 'Token nao pode estar vazio.', 
          ephemeral: true 
        });
      }

      console.log(`Validando token: ${tokenValue.substring(0, 20)}...`);
      
      const validation = await validateUserToken(tokenValue);
      
      if (validation.type === 'user' && validation.data.id !== interaction.user.id) {
        throw new Error('Este token nao pertence a sua conta Discord!');
      }

      const db = readDB();
      db[interaction.user.id] = {
        token: tokenValue,
        type: validation.type,
        username: validation.data.username,
        discriminator: validation.data.discriminator,
        userId: validation.data.id,
        addedAt: new Date().toISOString(),
        lastValidated: new Date().toISOString()
      };

      if (!writeDB(db)) {
        throw new Error('Erro ao salvar token no banco de dados.');
      }

      console.log(`Token vinculado para ${interaction.user.tag} (Tipo: ${validation.type})`);

      const successEmbed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle('Token Vinculado com Sucesso!')
        //.setDescription(`**Conta validada:** ${validation.data.username}#${validation.data.discriminator}`)
        .addFields(
          //{ name: 'ID da Conta', value: validation.data.id, inline: true },
          //{ name: 'Tipo', value: validation.type === 'user' ? 'Token de Usuario' : 'Token de Bot', inline: true },
          //{ name: 'Velocidade', value: '1 msg/3 segundos', inline: true },
          //{ name: 'Status', value: 'Pronto para uso', inline: false },
          { name: 'Proximo passo:', value: 'Agora você pode usar o **CL.**', inline: false }
        )
        .setFooter({ text: 'Token armazenado com seguranca.' });

      await interaction.reply({ embeds: [successEmbed], ephemeral: true });

    } catch (error) {
      console.error('Erro no handleModal:', error);
      
      const helpEmbed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle('Falha na Validação do Token')
      .setDescription(`**Erro:** ${error.message}`)
      .addFields(
        { 
          name: 'Seu token está correto?', 
          value: 
            'Tente as seguintes soluções:\n\n' +
            '• **Token expirado** - Troque sua senha para que o token seja resetado ou alterado, e tente novamente.\n' +
            '• **Conta com 2FA** - Se sua conta tiver autenticação de dois fatores, o token deve começar com `mfa.`\n'
            //'• **Problema temporário** - Pode ser um erro momentâneo. Tente novamente em alguns minutos.'
        }
      )
      .setFooter({ text: 'Em caso de dúvidas, entre em contato com o suporte.' });
    
    await interaction.reply({ embeds: [helpEmbed], ephemeral: true });
    }
  },

  async resetToken(interaction) {
    try {
      console.log(`Usuario ${interaction.user.tag} solicitou RESET TOKEN`);
      
      const db = readDB();
      if (!db[interaction.user.id]) {
        return await interaction.reply({ 
          content: 'Nenhum token vinculado encontrado para sua conta.', 
          ephemeral: true 
        });
      }

      const userData = db[interaction.user.id];

      console.log(`Resetando token para ${interaction.user.tag}`);
      
      delete db[interaction.user.id];
      
      if (writeDB(db)) {
        console.log(`Token removido para ${interaction.user.tag}`);
        
        const successEmbed = new EmbedBuilder()
          .setColor(0x00ff00)
          .setTitle('Token Resetado com Sucesso!')
          //.setDescription(`**Conta removida:** ${userData.username}#${userData.discriminator}`)
          .addFields(
            //{ name: 'ID da Conta', value: userData.userId, inline: true },
            //{ name: 'Vinculado em', value: new Date(userData.addedAt).toLocaleString('pt-BR'), inline: true },
            { name: 'Status', value: 'Token removido do sistema.', inline: false }
          )
          .setFooter({ text: 'Você pode vincular um novo token a qualquer momento.' });

        await interaction.reply({ 
          embeds: [successEmbed], 
          ephemeral: true 
        });
      } else {
        throw new Error('Erro ao remover token do banco de dados.');
      }

    } catch (error) {
      console.error('Erro no resetToken:', error);
      
      const errorEmbed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle('Erro ao Resetar Token')
        .setDescription(`**Erro:** ${error.message}`)
        .setFooter({ text: 'Tente novamente ou contate o suporte' });

      await interaction.reply({ 
        embeds: [errorEmbed], 
        ephemeral: true 
      });
    }
  },

  hasToken(userId) {
    const db = readDB();
    return !!db[userId];
  },

  getUserToken(userId) {
    const db = readDB();
    return db[userId] ? db[userId].token : null;
  }
};