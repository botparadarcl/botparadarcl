require('dotenv').config();
const {
  Client, GatewayIntentBits, Partials,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, StringSelectMenuBuilder, PermissionsBitField
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

const cldm = require('./cl_dm.js');
const addToken = require('./add_token.js');
const ren = require('./ren.js');

client.once('ready', () => {
  console.log(`Bot online como ${client.user.tag}`);
  console.log(`Conectado em ${client.guilds.cache.size} servidores`);

  // Iniciar reinicio automatico a cada 1 hora
  ren.startAutoRestart(client);
});

// ---------- Comando de configuracao ----------
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // Comando de configuracao
  if (message.content.toLowerCase() === 'cl!config') {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      const warn = await message.reply({
        content: 'Voce nao tem permissao para usar este comando. (Somente administradores)',
      });
      setTimeout(() => {
        warn.delete().catch(() => { });
        message.delete().catch(() => { });
      }, 5000);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#000000')
      .setTitle('Configuracao do Bot')
      .setDescription('Escolha um canal para cada funcao:');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('add_cl').setLabel('Add CL').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('add_logs').setLabel('Add LOGS').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('add_not').setLabel('Add NOT').setStyle(ButtonStyle.Secondary)
    );

    await message.reply({ embeds: [embed], components: [row] });
    return;
  }

  // Comando para verificar status do sistema (apenas admins)
  if (message.content.toLowerCase() === 'cl!status' && message.member.permissions.has('Administrator')) {
    const status = ren.getSystemStatus();

    const statusEmbed = new EmbedBuilder()
      .setColor(status.inProgress ? 0xffa500 : 0x00ff00)
      .setTitle('Status do Sistema')
      .addFields(
        { name: 'Processos Ativos', value: status.inProgress ? 'Sim' : 'Nao', inline: true },
        { name: 'Ultimo Reinicio', value: status.lastRestart ? new Date(status.lastRestart).toLocaleString('pt-BR') : 'Nunca', inline: true }
      )
      .setTimestamp();

    await message.reply({ embeds: [statusEmbed] });
    await message.delete().catch(() => { });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton() && !interaction.isStringSelectMenu() && !interaction.isModalSubmit()) return;

  try {
    // ----- Selecao de canal -----
    if (interaction.isButton() && ['add_cl', 'add_logs', 'add_not'].includes(interaction.customId)) {
      const channelSelect = new StringSelectMenuBuilder()
        .setCustomId(`channel_select_${interaction.customId}`)
        .setPlaceholder('Selecione um canal')
        .setMinValues(1).setMaxValues(1)
        .addOptions(
          interaction.guild.channels.cache
            .filter(c => c.isTextBased() && c.viewable)
            .map(c => ({ label: `#${c.name}`, value: c.id }))
            .slice(0, 25)
        );

      await interaction.reply({
        content: `Escolha o canal para ${interaction.customId.replace('add_', '').toUpperCase()}:`,
        components: [new ActionRowBuilder().addComponents(channelSelect)],
        ephemeral: true
      });
      return;
    }

    // ----- Menu de selecao do Token -----
    if (interaction.isStringSelectMenu() && interaction.customId === 'token_menu_select') {
      const selectedValue = interaction.values[0];

      switch (selectedValue) {
        case 'activate_token':
          return addToken.showAddTokenModal(interaction);

        case 'reset_token':
          return addToken.resetToken(interaction);
      }
    }

    // ----- Apos escolher o canal -----
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('channel_select_')) {
      const [, action] = interaction.customId.split('channel_select_');
      const channelId = interaction.values[0];
      const channel = interaction.guild.channels.cache.get(channelId);

      if (!channel) {
        return interaction.update({ content: 'Canal nao encontrado!', components: [] });
      }

      if (action === 'add_cl') {
        const { createCLMessage } = require('./ui_cl_message.js');
        await channel.send(await createCLMessage());
        await interaction.update({
          content: `Add CL configurado em ${channel}`,
          components: []
        });
        return;
      }

      if (action === 'add_logs') {
        const dbPath = path.join(__dirname, 'userKeys.json');
        const db = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath, 'utf8')) : {};
        db.logsChannel = channel.id;
        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        await interaction.update({
          content: `Logs configurado em ${channel}`,
          components: []
        });
        return;
      }

      if (action === 'add_not') {
        const dbPath = path.join(__dirname, 'userKeys.json');
        const db = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath, 'utf8')) : {};
        db.notChannel = channel.id;
        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

        const notEmbed = new EmbedBuilder()
          .setColor('#9b59b6')
          .setTitle('📢 Canal de Notificacoes')
          .setDescription('Este canal recebera notificacoes sobre reinicios automaticos do sistema.');

        await channel.send({ embeds: [notEmbed] });
        await interaction.update({
          content: `Add NOT configurado em ${channel}`,
          components: []
        });
        return;
      }
    }

    // ----- Botoes dentro do CL -----
    if (interaction.isButton()) {
      switch (interaction.customId) {
        case 'cl_dm':
          return cldm.start(interaction, client);

        case 'token_menu':
          // Criar menu de selecao para token
          const tokenMenu = new StringSelectMenuBuilder()
            .setCustomId('token_menu_select')
            .setPlaceholder('Escolha uma opcao')
            .addOptions([
              {
                label: 'Ativar Token',
                description: 'Vincular novo token a sua conta',
                value: 'activate_token'
              },
              {
                label: 'Resetar Token',
                description: 'Remover token vinculado',
                value: 'reset_token'
              }
            ]);

          await interaction.reply({
            content: 'Gerenciar Token',
            components: [new ActionRowBuilder().addComponents(tokenMenu)],
            ephemeral: true
          });
          return;
      }
    }

    // ----- Modal de token -----
    if (interaction.isModalSubmit() && interaction.customId === 'add_token_modal') {
      return addToken.handleModal(interaction);
    }

  } catch (error) {
    console.error('Erro na interacao:', error);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({
        content: 'Ocorreu um erro. Tente novamente.',
        ephemeral: true
      });
    } else {
      await interaction.reply({
        content: 'Ocorreu um erro. Tente novamente.',
        ephemeral: true
      });
    }
  }
});

// Tratamento de erros globais
process.on('unhandledRejection', (error) => {
  console.error('Erro nao tratado:', error);
});

process.on('uncaughtException', (error) => {
  console.error('Excecao nao capturada:', error);
});

client.login(process.env.TOKEN).catch(error => {
  console.error('Erro ao fazer login:', error);
  process.exit(1);
});

// Comando para verificar o status do sistema
/*client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // Comando para verificar status do sistema (apenas admins)
  if (message.content.toLowerCase() === 'cl!status' && message.member.permissions.has('Administrator')) {
    const status = ren.getSystemStatus();

    const statusEmbed = new EmbedBuilder()
      .setColor(status.inProgress ? 0xffa500 : 0x00ff00)
      .setTitle('Status do Sistema CL DM')
      .addFields(
        { name: 'Processo Ativo', value: status.inProgress ? 'Sim' : 'Nao', inline: true },
        { name: 'Usuario Atual', value: status.currentUser ? `<@${status.currentUser}>` : 'Nenhum', inline: true },
        { name: 'Inicio', value: status.startTime ? new Date(status.startTime).toLocaleString('pt-BR') : 'N/A', inline: true },
        { name: 'Tokens', value: status.totalTokens.toString(), inline: true },
        { name: 'Ultimo Reinicio', value: status.lastRestart ? new Date(status.lastRestart).toLocaleString('pt-BR') : 'Nunca', inline: true }
      )
      .setFooter({ text: 'Status em tempo real' })
      .setTimestamp();

    await message.reply({ embeds: [statusEmbed] });
    await message.delete().catch(() => { });
  }
});*/

// Funcao para enviar notificacao de reinicio (deve ser chamada pelo modulo ren.js)
async function sendRestartNotification(client) {
  try {
    const dbPath = path.join(__dirname, 'userKeys.json');
    if (fs.existsSync(dbPath)) {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      if (db.notChannel) {
        const channel = client.channels.cache.get(db.notChannel);
        if (channel) {
          const restartEmbed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setTitle('Reinicio do Sistema')
            .setDescription('Bot reiniciado com sucesso e estou online novamente. Todas as atividades foram encerradas. Pode usar novamente o sistema normalmente.')
            .setTimestamp();

          await channel.send({ embeds: [restartEmbed] });
        }
      }
    }
  } catch (error) {
    console.error('Erro ao enviar notificacao de reinicio:', error);
  }
}

// Exportar a funcao para ser usada pelo modulo ren.js
module.exports = { sendRestartNotification };