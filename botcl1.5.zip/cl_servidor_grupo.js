const fs = require('fs');
const path = require('path');
const usedPath = path.join(__dirname, 'usedOnce.json');
const addToken = require('./add_token.js');
const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

function readUsed() {
    if (!fs.existsSync(usedPath)) return {};
    return JSON.parse(fs.readFileSync(usedPath, 'utf8'));
}

function writeUsed(data) {
    fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
}

function resetUserState(userId) {
    const used = readUsed();
    if (used.inProgress && used.user === userId) {
        used.inProgress = false;
        delete used.user;
        delete used.startTime;
        delete used.targetChannelId;
        writeUsed(used);
        console.log(`Estado resetado para o usuario: ${userId}`);
    }
}

class ServerGroupDeleter {
    constructor(userToken, userId) {
        this.options = {
            authToken: userToken,
            deleteDelay: 500,
            maxAttempts: 5,
            parallelDeletes: 2,
            fetchLimit: 100
        };
        this.userId = userId;
        this.state = {
            running: false,
            deletedCount: 0,
            failedCount: 0,
            totalMessages: 0,
            currentBatch: 0,
            startTime: null,
            emptyBatches: 0,
            processedChannels: 0,
            successfulChannels: 0,
            failedChannels: 0
        };
    }

    async validateToken() {
        try {
            const response = await fetch('https://discord.com/api/v9/users/@me', {
                headers: {
                    'Authorization': this.options.authToken
                }
            });
            
            if (response.ok) {
                const userData = await response.json();
                return userData.id === this.userId;
            } else if (response.status === 401) {
                throw new Error('Token invalido');
            }
            return false;
        } catch (error) {
            console.error('Erro na validacao do token:', error);
            return false;
        }
    }

    async deleteChannelMessages(channelId) {
        if (this.state.running) {
            throw new Error('Ja esta em execucao!');
        }

        if (!await this.validateToken()) {
            throw new Error('Token de autenticacao invalido ou não pertence a este usuario');
        }

        this.state.running = true;
        this.state.deletedCount = 0;
        this.state.failedCount = 0;
        this.state.totalMessages = 0;
        this.state.currentBatch = 0;
        this.state.startTime = Date.now();
        this.state.emptyBatches = 0;

        try {
            console.log(`Iniciando exclusao para o canal: ${channelId}`);

            // FASE 1: Deleção principal
            await this.fetchAndDeleteUserMessages(channelId);
            
            // FASE 2: Verificação e retry
            console.log('Iniciando verificacao final do canal...');
            const remaining = await this.checkRemainingMessages(channelId);
            
            if (remaining > 0) {
                console.log(`Encontradas ${remaining} mensagens restantes no canal, reiniciando delecao...`);
                await this.fetchAndDeleteUserMessages(channelId, true);
                
                // Verificação final
                const finalRemaining = await this.checkRemainingMessages(channelId);
                if (finalRemaining > 0) {
                    console.log(`ATENCAO: Ainda restam ${finalRemaining} mensagens no canal apos segunda tentativa`);
                }
            }

            return this.generateReport();

        } catch (error) {
            console.error('Erro no processo do canal:', error);
            return {
                success: false,
                error: error.message,
                ...this.getCurrentStats()
            };
        } finally {
            this.state.running = false;
            console.log('Processo do canal finalizado');
        }
    }

    async deleteServerMessages(guildId) {
        if (this.state.running) {
            throw new Error('Ja esta em execucao!');
        }

        if (!await this.validateToken()) {
            throw new Error('Token de autenticacao invalido ou não pertence a este usuario');
        }

        this.state.running = true;
        this.state.deletedCount = 0;
        this.state.failedCount = 0;
        this.state.totalMessages = 0;
        this.state.currentBatch = 0;
        this.state.startTime = Date.now();
        this.state.processedChannels = 0;
        this.state.successfulChannels = 0;
        this.state.failedChannels = 0;

        let channelsWithRemaining = [];

        try {
            console.log(`Iniciando exclusao para o servidor: ${guildId}`);

            const channels = await this.fetchAccessibleChannels(guildId);
            console.log(`Canais acessiveis encontrados: ${channels.length}`);

            if (channels.length === 0) {
                throw new Error('Nenhum canal acessivel encontrado no servidor');
            }

            for (const channel of channels) {
                if (!this.state.running) break;
                
                this.state.processedChannels++;
                console.log(`[${this.state.processedChannels}/${channels.length}] Processando canal: ${channel.name} (${channel.id})`);
                
                try {
                    const beforeCount = this.state.deletedCount;
                    await this.fetchAndDeleteUserMessages(channel.id);
                    const deletedInChannel = this.state.deletedCount - beforeCount;
                    
                    // Verificar se ainda há mensagens restantes
                    const remaining = await this.checkRemainingMessages(channel.id);
                    
                    if (deletedInChannel > 0) {
                        if (remaining > 0) {
                            console.log(`⚠️ Canal ${channel.name}: ${deletedInChannel} deletadas, mas ${remaining} restantes`);
                            channelsWithRemaining.push({ name: channel.name, id: channel.id, remaining });
                            this.state.successfulChannels++;
                        } else {
                            console.log(`✅ Canal ${channel.name}: ${deletedInChannel} mensagens deletadas completamente`);
                            this.state.successfulChannels++;
                        }
                    } else {
                        console.log(`ℹ️ Canal ${channel.name}: Nenhuma mensagem do usuario encontrada`);
                        this.state.successfulChannels++;
                    }
                    
                } catch (error) {
                    console.log(`❌ Erro no canal ${channel.name}: ${error.message}`);
                    this.state.failedChannels++;
                    channelsWithRemaining.push({ name: channel.name, id: channel.id, error: error.message });
                }
            }

            // FASE 2: Tentar novamente nos canais com mensagens restantes
            if (channelsWithRemaining.length > 0) {
                console.log(`Tentando novamente em ${channelsWithRemaining.length} canais com mensagens restantes...`);
                
                for (const channelInfo of channelsWithRemaining) {
                    if (!this.state.running) break;
                    
                    try {
                        console.log(`Retentando canal: ${channelInfo.name}`);
                        await this.fetchAndDeleteUserMessages(channelInfo.id, true);
                        
                        // Verificação final
                        const finalRemaining = await this.checkRemainingMessages(channelInfo.id);
                        if (finalRemaining === 0) {
                            console.log(`✅ Canal ${channelInfo.name}: Todas as mensagens removidas na segunda tentativa`);
                            // Atualizar contadores
                            const index = channelsWithRemaining.findIndex(c => c.id === channelInfo.id);
                            if (index !== -1) {
                                channelsWithRemaining.splice(index, 1);
                                this.state.failedChannels--;
                                this.state.successfulChannels++;
                            }
                        }
                    } catch (error) {
                        console.log(`❌ Falha na segunda tentativa do canal ${channelInfo.name}: ${error.message}`);
                    }
                }
            }

            console.log(`Processamento concluido: ${this.state.successfulChannels}/${channels.length} canais processados com sucesso, ${this.state.failedChannels} falharam`);
            console.log(`Canais com mensagens restantes: ${channelsWithRemaining.length}`);

            return this.generateReport(channelsWithRemaining);

        } catch (error) {
            console.error('Erro no processo do servidor:', error);
            return {
                success: false,
                error: error.message,
                ...this.getCurrentStats()
            };
        } finally {
            this.state.running = false;
            console.log('Processo do servidor finalizado');
        }
    }

    async fetchAndDeleteUserMessages(channelId, isRetry = false) {
        let beforeMessageId = null;
        let hasMoreMessages = true;
        let consecutiveEmpty = 0;
        const maxConsecutiveEmpty = 3;

        try {
            while (hasMoreMessages && this.state.running && consecutiveEmpty < maxConsecutiveEmpty) {
                try {
                    this.state.currentBatch++;
                    console.log(`Lote ${this.state.currentBatch} no canal ${channelId} ${isRetry ? '(RETRY)' : ''}...`);

                    const messages = await this.fetchMessages(channelId, beforeMessageId);

                    if (messages.length === 0) {
                        console.log(`Fim das mensagens no canal ${channelId}`);
                        consecutiveEmpty++;
                        hasMoreMessages = false;
                        continue;
                    }

                    const userMessages = messages.filter(msg => msg.author.id === this.userId);
                    this.state.totalMessages += userMessages.length;

                    console.log(`${userMessages.length} mensagens do usuario no lote (Total: ${this.state.totalMessages})`);

                    if (userMessages.length === 0) {
                        console.log('Nenhuma mensagem do usuario neste lote');
                        consecutiveEmpty++;
                        beforeMessageId = messages[messages.length - 1]?.id;
                        
                        if (consecutiveEmpty >= maxConsecutiveEmpty) {
                            console.log(`Parando apos ${maxConsecutiveEmpty} lotes vazios consecutivos`);
                            hasMoreMessages = false;
                        }
                        continue;
                    } else {
                        consecutiveEmpty = 0;
                    }

                    // Deletar em sequência para melhor confiabilidade
                    for (const msg of userMessages) {
                        if (!this.state.running) {
                            console.log('Processo interrompido pelo usuario');
                            return;
                        }

                        const success = await this.deleteSingleMessage(msg, channelId);
                        if (success) {
                            this.state.deletedCount++;
                            if (this.state.deletedCount % 10 === 0) {
                                console.log(`${this.state.deletedCount} mensagens deletadas...`);
                            }
                        } else {
                            this.state.failedCount++;
                        }

                        await this.delay(this.options.deleteDelay);
                    }

                    beforeMessageId = messages[messages.length - 1]?.id;

                    if (this.state.deletedCount % 50 === 0 && this.state.deletedCount > 0) {
                        const elapsed = (Date.now() - this.state.startTime) / 1000;
                        console.log(`Progresso: ${this.state.deletedCount} deletadas em ${elapsed.toFixed(1)}s`);
                    }

                } catch (error) {
                    console.error('Erro no processamento do lote:', error);
                    consecutiveEmpty++;
                    if (consecutiveEmpty >= maxConsecutiveEmpty) {
                        hasMoreMessages = false;
                    }
                    await this.delay(2000);
                }
            }

        } catch (error) {
            console.error('Erro geral no fetchAndDeleteUserMessages:', error);
            throw error;
        }
    }

    async checkRemainingMessages(channelId) {
        console.log(`Verificando mensagens restantes no canal ${channelId}...`);
        let totalRemaining = 0;
        let beforeMessageId = null;
        let hasMore = true;
        let batchesChecked = 0;

        try {
            while (hasMore && batchesChecked < 5) {
                const messages = await this.fetchMessages(channelId, beforeMessageId);
                
                if (messages.length === 0) {
                    hasMore = false;
                    continue;
                }

                const userMessages = messages.filter(msg => msg.author.id === this.userId);
                totalRemaining += userMessages.length;
                
                batchesChecked++;
                beforeMessageId = messages[messages.length - 1]?.id;

                if (userMessages.length > 0) {
                    console.log(`Lote ${batchesChecked} no canal ${channelId}: ${userMessages.length} mensagens restantes`);
                }
            }

            console.log(`Verificacao do canal ${channelId} concluida: ${totalRemaining} mensagens restantes`);
            return totalRemaining;

        } catch (error) {
            console.error('Erro na verificacao do canal:', error);
            return -1;
        }
    }

    generateReport(channelsWithRemaining = []) {
        const totalTime = (Date.now() - this.state.startTime) / 1000;
        const successRate = this.state.totalMessages > 0 ? 
            (this.state.deletedCount / this.state.totalMessages * 100).toFixed(1) : 0;
        
        const allDeleted = this.state.failedCount === 0 && 
                          this.state.deletedCount === this.state.totalMessages &&
                          channelsWithRemaining.length === 0;
        
        return {
            success: allDeleted || this.state.deletedCount > 0,
            deleted: this.state.deletedCount,
            failed: this.state.failedCount,
            total: this.state.totalMessages,
            batches: this.state.currentBatch,
            successRate: `${successRate}%`,
            totalTime: `${totalTime.toFixed(1)}s`,
            averageSpeed: totalTime > 0 ? `${(this.state.deletedCount / totalTime).toFixed(1)} msg/s` : '0 msg/s',
            completelyCleaned: allDeleted,
            channelsProcessed: this.state.processedChannels,
            channelsSuccessful: this.state.successfulChannels,
            channelsFailed: this.state.failedChannels,
            channelsWithRemaining: channelsWithRemaining.length
        };
    }

    getCurrentStats() {
        const totalTime = this.state.startTime ? (Date.now() - this.state.startTime) / 1000 : 0;
        return {
            deleted: this.state.deletedCount,
            failed: this.state.failedCount,
            batches: this.state.currentBatch,
            totalTime: `${totalTime.toFixed(1)}s`,
            totalMessages: this.state.totalMessages,
            channelsProcessed: this.state.processedChannels
        };
    }

    async fetchAccessibleChannels(guildId) {
        try {
            console.log(`Buscando canais do servidor: ${guildId}`);
            
            const response = await fetch(`https://discord.com/api/v9/guilds/${guildId}/channels`, {
                headers: {
                    'Authorization': this.options.authToken,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const channels = await response.json();
                console.log(`Total de canais retornados pela API: ${channels.length}`);
                
                const textChannels = channels.filter(channel => channel.type === 0);
                console.log(`Canais de texto encontrados: ${textChannels.length}`);

                const accessibleChannels = [];
                
                for (const channel of textChannels) {
                    try {
                        const testResponse = await fetch(
                            `https://discord.com/api/v9/channels/${channel.id}/messages?limit=1`,
                            {
                                headers: {
                                    'Authorization': this.options.authToken,
                                    'Content-Type': 'application/json'
                                }
                            }
                        );

                        if (testResponse.ok || testResponse.status === 404) {
                            accessibleChannels.push(channel);
                            console.log(`✅ Acesso permitido: ${channel.name} (${channel.id})`);
                        } else if (testResponse.status === 403) {
                            console.log(`❌ Sem acesso: ${channel.name} (${channel.id})`);
                        } else {
                            accessibleChannels.push(channel);
                            console.log(`⚠️ Status ${testResponse.status} em: ${channel.name} (${channel.id})`);
                        }

                        await this.delay(200);

                    } catch (error) {
                        console.log(`Erro ao testar canal ${channel.name}: ${error.message}`);
                    }
                }

                console.log(`Canais acessiveis totais: ${accessibleChannels.length}`);
                
                if (accessibleChannels.length === 0) {
                    throw new Error('Nenhum canal acessivel encontrado neste servidor');
                }

                return accessibleChannels;
            } else if (response.status === 401) {
                throw new Error('Token invalido');
            } else if (response.status === 403) {
                throw new Error('Sem acesso ao servidor ou servidor não encontrado');
            } else if (response.status === 404) {
                throw new Error('Servidor não encontrado');
            } else {
                console.log(`Erro API servidor: ${response.status} - ${response.statusText}`);
                throw new Error(`Erro ao acessar servidor: ${response.status}`);
            }
        } catch (error) {
            console.error('Erro ao buscar canais do servidor:', error);
            throw error;
        }
    }

    async fetchMessages(channelId, beforeId = null) {
        const params = new URLSearchParams({ limit: this.options.fetchLimit.toString() });
        if (beforeId) params.append('before', beforeId);

        try {
            const response = await fetch(
                `https://discord.com/api/v9/channels/${channelId}/messages?${params}`,
                {
                    headers: {
                        'Authorization': this.options.authToken,
                        'Content-Type': 'application/json'
                    }
                }
            );

            if (response.ok) {
                return await response.json();
            } else if (response.status === 429) {
                const rateLimitData = await response.json();
                const retryAfter = rateLimitData.retry_after * 1000;
                console.log(`Rate limit atingido. Esperando ${retryAfter}ms...`);
                await this.delay(retryAfter + 1000);
                return await this.fetchMessages(channelId, beforeId);
            } else if (response.status === 401) {
                throw new Error('Token invalido');
            } else if (response.status === 403) {
                throw new Error('Sem permissao para acessar este canal');
            } else if (response.status === 404) {
                throw new Error('Canal não encontrado');
            } else {
                throw new Error(`Erro API: ${response.status}`);
            }
        } catch (error) {
            console.error('Erro na requisicao de mensagens:', error);
            throw error;
        }
    }

    async deleteSingleMessage(message, channelId) {
        let attempt = 0;

        while (attempt < this.options.maxAttempts) {
            try {
                const response = await fetch(
                    `https://discord.com/api/v9/channels/${channelId}/messages/${message.id}`,
                    {
                        method: 'DELETE',
                        headers: {
                            'Authorization': this.options.authToken,
                            'Content-Type': 'application/json'
                        }
                    }
                );

                if (response.ok) {
                    return true;
                } else if (response.status === 429) {
                    const rateLimitData = await response.json();
                    const retryAfter = rateLimitData.retry_after * 1000;
                    console.log(`Rate limit na delecao. Esperando ${retryAfter}ms...`);
                    await this.delay(retryAfter);
                    attempt++;
                } else if (response.status === 401) {
                    throw new Error('Token invalido');
                } else if (response.status === 404) {
                    console.log('Mensagem ja deletada ou não encontrada');
                    return true;
                } else if (response.status === 403) {
                    console.log('Sem permissao para deletar esta mensagem');
                    return false;
                } else {
                    console.log(`Erro ${response.status} na delecao, tentativa ${attempt + 1}`);
                    attempt++;
                    await this.delay(1000);
                }
            } catch (error) {
                console.error('Erro na tentativa de delecao:', error);
                attempt++;
                await this.delay(1000);
            }
        }

        console.log(`Falha apos ${this.options.maxAttempts} tentativas para mensagem ${message.id}`);
        return false;
    }

    stop() {
        this.state.running = false;
        console.log('Processo de delecao interrompido');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

module.exports = {
    async start(interaction, client) {
        const used = readUsed();
        if (used.inProgress && used.user === interaction.user.id) {
            const progressEmbed = new EmbedBuilder()
                .setColor(0xFFA500)
                .setTitle('Limpeza em Andamento')
                .setDescription('Voce ja tem uma limpeza em progresso.\n\nAguarde a limpeza atual ser concluida antes de iniciar uma nova.')
                .addFields(
                    { name: 'Status', value: 'Processando...', inline: true },
                    { name: 'Iniciado em', value: used.startTime ? new Date(used.startTime).toLocaleString('pt-BR') : 'Recentemente', inline: true }
                )
                .setFooter({ text: 'Aguarde a conclusao para iniciar uma nova limpeza.' });

            return await interaction.reply({ 
                embeds: [progressEmbed], 
                ephemeral: true 
            });
        }

        resetUserState(interaction.user.id);

        if (!addToken.hasToken(interaction.user.id)) {
            return interaction.reply({
                embeds: [{
                    color: 0xFF0000,
                    title: 'Token não vinculado!',
                    description: 'Voce precisa vincular seu token primeiro!',
                    fields: [
                        {
                            name: 'Instrucoes:',
                            value: '1. Clique em "Token"\n2. Cole o token da sua conta Discord\n3. Use "CL SERV/GRUPO" apos vincular',
                        },
                    ],
                    footer: {
                        text: 'Caso tenha alguma duvida, entre em contato com o suporte.',
                    },
                    timestamp: new Date(),
                }],
                ephemeral: true,
            });
        }

        const userTokenData = addToken.getUserTokenData(interaction.user.id);
        if (userTokenData && userTokenData.userId !== interaction.user.id) {
            const warningMessage = await interaction.reply({ 
                content: `||<@${interaction.user.id}>|| **ATENCAO**: O token vinculado não pertence a sua conta!\n\nPor favor, use o comando **Token** → **Resetar Token** e depois vincule o token da **SUA** conta.`,
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await warningMessage.delete();
                } catch (error) {
                    console.log('Mensagem ja foi deletada ou não encontrada');
                }
            }, 15000);
            
            return;
        }

        const typeEmbed = new EmbedBuilder()
            .setColor(0x0099ff)
            .setTitle('CL SERV/GRUPO')
            .setDescription('Escolha o tipo de limpeza que deseja realizar:\n\n' +
                '• **Servidor** - Deleta suas mensagens de todos os canais de um servidor\n' +
                '• **Grupo/Canal** - Deleta suas mensagens de um canal especifico (grupo ou canal de servidor)')
            .setFooter({ 
                text: 'Voce tem 30 segundos para escolher' 
            });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('servidor_type')
                .setLabel('Servidor')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('grupo_type')
                .setLabel('Grupo/Canal')
                .setStyle(ButtonStyle.Secondary)
        );

        await interaction.reply({
            embeds: [typeEmbed],
            components: [row],
            ephemeral: true
        });

        const filter = i => i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({
            filter,
            time: 30000,
            max: 1
        });

        collector.on('collect', async (i) => {
            await i.deferUpdate();
            
            const isServer = i.customId === 'servidor_type';
            
            const idEmbed = new EmbedBuilder()
                .setColor(0x0099ff)
                .setTitle(isServer ? 'Digite o ID do Servidor' : 'Digite o ID do Canal')
                .setDescription(`Envie apenas o ID numerico ${isServer ? 'do servidor' : 'do canal'}.\n\n**Voce tem 30 segundos para enviar o ID.**`)
                .setFooter({ 
                    text: isServer ? 
                        'Como obter: Clique com botao direito no servidor → Copiar ID' :
                        'Como obter: Clique com botao direito no canal → Copiar ID'
                });

            await interaction.editReply({
                embeds: [idEmbed],
                components: []
            });

            const idFilter = m => m.author.id === interaction.user.id;
            const idCollector = interaction.channel.createMessageCollector({
                filter: idFilter,
                time: 30000,
                max: 1
            });

            idCollector.on('collect', async targetMessage => {
                await targetMessage.delete().catch(() => { });
                const targetId = targetMessage.content.trim();

                if (!targetId.match(/^\d{17,20}$/)) {
                    resetUserState(interaction.user.id);
                    return interaction.followUp({
                        content: 'ID invalido!\n\n' +
                            'O ID deve conter 17-20 digitos numericos.\n' +
                            'Exemplo correto: 123456789012345678',
                        ephemeral: true
                    });
                }

                used.inProgress = true;
                used.user = interaction.user.id;
                used.startTime = new Date().toISOString();
                used.targetChannelId = targetId;
                used.isServer = isServer;
                writeUsed(used);

                const progressEmbed = new EmbedBuilder()
                    .setColor(0x0099FF)
                    .setTitle('Iniciando processo de exclusao...')
                    .setDescription(`Processando ${isServer ? 'servidor' : 'canal'}...\nNão feche a janela.`)
                    .setTimestamp();

                const progressMessage = await interaction.followUp({
                    embeds: [progressEmbed],
                    ephemeral: true
                });

                try {
                    const userToken = addToken.getUserToken(interaction.user.id);
                    const deleter = new ServerGroupDeleter(userToken, interaction.user.id);

                    let lastUpdate = 0;
                    let progressUpdater;

                    const updateProgress = async () => {
                        const now = Date.now();
                        if (now - lastUpdate < 2000) return;

                        lastUpdate = now;
                        try {
                            const stats = deleter.getCurrentStats();
                            const progressEmbed = new EmbedBuilder()
                                .setColor(0x0099FF)
                                .setTitle('Processando exclusao...')
                                .setDescription(`Processando ${isServer ? 'servidor' : 'canal'}...\nNão feche a janela.`)
                                .addFields(
                                    { name: 'Deletadas', value: deleter.state.deletedCount.toString(), inline: true },
                                    { name: 'Falhas', value: deleter.state.failedCount.toString(), inline: true },
                                    { name: 'Tempo', value: stats.totalTime, inline: true },
                                    { name: 'Lotes', value: deleter.state.currentBatch.toString(), inline: true },
                                    { name: 'Total', value: deleter.state.totalMessages.toString(), inline: true },
                                    { name: 'Canais', value: `${deleter.state.processedChannels || 0} processados`, inline: true }
                                )
                                .setTimestamp();

                            await progressMessage.edit({ embeds: [progressEmbed] });
                        } catch (error) {
                            console.log('Mensagem de progresso ja atualizada');
                        }
                    };

                    const startTime = Date.now();
                    progressUpdater = setInterval(updateProgress, 1000);

                    console.log(`Iniciando processo de delecao para ${isServer ? 'servidor' : 'canal'}: ${targetId}`);
                    
                    let result;
                    if (isServer) {
                        result = await deleter.deleteServerMessages(targetId);
                    } else {
                        result = await deleter.deleteChannelMessages(targetId);
                    }
                    
                    console.log('Processo de delecao concluido:', result);

                    clearInterval(progressUpdater);
                    resetUserState(interaction.user.id);

                    const totalTime = Math.floor((Date.now() - startTime) / 1000);
                    console.log(`Tempo total do processo: ${totalTime} segundos`);

                    await this.sendLogs(client, interaction, targetId, result, totalTime, isServer);

                    let finalEmbed;

                    if (result.completelyCleaned) {
                        finalEmbed = new EmbedBuilder()
                            .setColor(0x00FF00)
                            .setTitle('CL SERV/GRUPO  foi concluido com sucesso.')
                            .setDescription('**Todas as suas mensagens foram deletadas completamente!**\n\nAltere a senha da sua conta para o token ser resetado. (Tudo por questao de seguranca)')
                            .addFields(
                                { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                                //{ name: 'Taxa de sucesso', value: result.successRate, inline: true },
                                //{ name: 'Tempo total', value: result.totalTime, inline: true },
                                { name: 'Canais processados', value: `${result.channelsSuccessful}/${result.channelsProcessed}`, inline: true }
                            )
                            .setTimestamp();
                    } else if (result.success) {
                        finalEmbed = new EmbedBuilder()
                            .setColor(0xFFA500)
                            .setTitle('⚠️ CL SERV/GRUPO parcialmente concluido')
                            .setDescription(`A maioria das mensagens foi deletada, mas ${result.channelsWithRemaining || result.failed} podem ter ficado para trás.\n\nAltere a senha da sua conta para o token ser resetado.`)
                            .addFields(
                                { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                                { name: 'Mensagens falhadas', value: result.failed.toString(), inline: true },
                                { name: 'Taxa de sucesso', value: result.successRate, inline: true },
                                { name: 'Canais processados', value: `${result.channelsSuccessful}/${result.channelsProcessed}`, inline: true }
                            )
                            .setTimestamp();
                    } else {
                        finalEmbed = new EmbedBuilder()
                            .setColor(0xFF0000)
                            .setTitle('❌ Erro na exclusao')
                            .setDescription(`Erro: ${result.error}`)
                            .addFields(
                                { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                                { name: 'Mensagens falhadas', value: result.failed.toString(), inline: true },
                                { name: 'Tempo decorrido', value: result.totalTime, inline: true }
                            )
                            .setTimestamp();
                    }

                    // Mensagem final some após 20 segundos
                    const finalMessage = await interaction.followUp({
                        embeds: [finalEmbed],
                        ephemeral: true,
                        fetchReply: true
                    });

                    // Deletar mensagem final após 20 segundos
                    setTimeout(async () => {
                        try {
                            await finalMessage.delete();
                        } catch (error) {
                            console.log('Mensagem final ja foi deletada ou não encontrada');
                        }
                    }, 20000);

                } catch (error) {
                    resetUserState(interaction.user.id);
                    console.error('Erro critico no processo:', error);

                    const errorEmbed = new EmbedBuilder()
                        .setColor(0xFF0000)
                        .setTitle('❌ Erro critico')
                        .setDescription(`Mensagem: ${error.message}\n\nSistema reiniciado. Tente novamente.`)
                        .setTimestamp();

                    // Mensagem de erro também some após 20 segundos
                    const errorMessage = await interaction.followUp({
                        embeds: [errorEmbed],
                        ephemeral: true,
                        fetchReply: true
                    });

                    setTimeout(async () => {
                        try {
                            await errorMessage.delete();
                        } catch (error) {
                            console.log('Mensagem de erro ja foi deletada ou não encontrada');
                        }
                    }, 20000);
                }
            });

            idCollector.on('end', (collected) => {
                if (collected.size === 0) {
                    resetUserState(interaction.user.id);
                    interaction.followUp({
                        content: 'Tempo esgotado para enviar o ID. Processo cancelado.',
                        ephemeral: true
                    });
                }
            });
        });

        collector.on('end', (collected) => {
            if (collected.size === 0) {
                resetUserState(interaction.user.id);
                interaction.followUp({
                    content: 'Tempo esgotado para escolher o tipo. Processo cancelado.',
                    ephemeral: true
                });
            }
        });
    },

    async sendLogs(client, interaction, targetId, result, totalTime, isServer) {
        try {
            const dbPath = path.join(__dirname, 'userKeys.json');
            if (fs.existsSync(dbPath)) {
                const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                if (db.logsChannel) {
                    const ch = client.channels.cache.get(db.logsChannel);
                    if (ch) {
                        if (result.completelyCleaned) {
                            await ch.send(`||<@${interaction.user.id}>|| Seu CL SERV/GRUPO foi concluido com sucesso.`);
                            //await ch.send(`||<@${interaction.user.id}>|| CL SERV/GRUPO foi concluido com sucesso. ${result.deleted} mensagens deletadas de ${isServer ? 'servidor' : 'canal'}.`);
                        } else if (result.success) {
                            await ch.send(`||<@${interaction.user.id}>|| ⚠️ CL SERV/GRUPO parcial: ${result.deleted} deletadas, ${result.failed} falhas em ${result.channelsProcessed} canais.`);
                        } else {
                            await ch.send(`||<@${interaction.user.id}>|| ❌ CL SERV/GRUPO com erro: ${result.error}`);
                        }
                    }
                }
            }
        } catch (error) {
            console.error('Erro ao enviar logs:', error);
        }
    }
};