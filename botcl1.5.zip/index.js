require('dotenv').config();
const {
  Client, GatewayIntentBits, Partials,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, StringSelectMenuBuilder, PermissionsBitField
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

const cldm = require('./cl_dm.js');
const addToken = require('./add_token.js');
const ren = require('./ren.js');

// Variável para controlar comandos em processamento
const processingCommands = new Set();

// Função para resetar estado do usuário
function resetUserState(userId) {
  const usedPath = path.join(__dirname, 'usedOnce.json');
  let used = {};

  try {
    if (fs.existsSync(usedPath)) {
      const data = fs.readFileSync(usedPath, 'utf8');
      used = data ? JSON.parse(data) : {};
    }

    if (used.inProgress && used.user === userId) {
      used.inProgress = false;
      delete used.user;
      delete used.startTime;
      delete used.targetUserId;
      delete used.targetChannelId;

      fs.writeFileSync(usedPath, JSON.stringify(used, null, 2));
      console.log(`✅ Estado resetado para o usuario: ${userId}`);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Erro ao resetar estado:', error);
    return false;
  }
}

client.once('ready', () => {
  console.log(`Bot online como ${client.user.tag}`);
  console.log(`Conectado em ${client.guilds.cache.size} servidores`);

  ren.startAutoRestart(client);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // VERIFICAÇÃO PARA EVITAR DUPLICAÇÃO
  const commandKey = `${message.id}-${message.author.id}`;
  if (processingCommands.has(commandKey)) {
    return;
  }
  processingCommands.add(commandKey);

  // Remove após 5 segundos para evitar memory leak
  setTimeout(() => {
    processingCommands.delete(commandKey);
  }, 5000);

  // COMANDO PARA RESETAR ESTADO
  if (message.content.toLowerCase() === 'cl!reset') {
    resetUserState(message.author.id);
    await message.reply({
      content: '✅ Estado resetado com sucesso! Agora você pode usar o CL novamente.',
      ephemeral: true
    });
    return;
  }

  if (message.content.toLowerCase() === 'cl!config') {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      const warn = await message.reply({
        content: 'Voce nao tem permissao para usar este comando. (Somente administradores)',
      });
      setTimeout(() => {
        warn.delete().catch(() => { });
        message.delete().catch(() => { });
      }, 5000);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#000000')
      .setTitle('Configuracao do Bot')
      .setDescription('Escolha um canal para cada funcao:');

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('add_cl').setLabel('Add CL').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('add_logs').setLabel('Add LOGS').setStyle(ButtonStyle.Secondary)
    );

    await message.reply({ embeds: [embed], components: [row] });
    return;
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton() && !interaction.isStringSelectMenu() && !interaction.isModalSubmit()) return;

  try {
    if (interaction.isButton() && ['add_cl', 'add_logs'].includes(interaction.customId)) {
      const channelSelect = new StringSelectMenuBuilder()
        .setCustomId(`channel_select_${interaction.customId}`)
        .setPlaceholder('Selecione um canal')
        .setMinValues(1).setMaxValues(1)
        .addOptions(
          interaction.guild.channels.cache
            .filter(c => c.isTextBased() && c.viewable)
            .map(c => ({ label: `#${c.name}`, value: c.id }))
            .slice(0, 25)
        );

      await interaction.reply({
        content: `Escolha o canal para ${interaction.customId.replace('add_', '').toUpperCase()}:`,
        components: [new ActionRowBuilder().addComponents(channelSelect)],
        ephemeral: true
      });
      return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'token_menu_select') {
      const selectedValue = interaction.values[0];

      switch (selectedValue) {
        case 'activate_token':
          return addToken.showAddTokenModal(interaction);

        case 'reset_token':
          return addToken.resetToken(interaction);
      }
    }

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('channel_select_')) {
      const [, action] = interaction.customId.split('channel_select_');
      const channelId = interaction.values[0];
      const channel = interaction.guild.channels.cache.get(channelId);

      if (!channel) {
        return interaction.update({ content: 'Canal nao encontrado!', components: [] });
      }

      if (action === 'add_cl') {
        // VERIFICA SE JÁ EXISTE MENSAGEM DO PAINEL CL NESTE CANAL
        const messages = await channel.messages.fetch({ limit: 10 });
        const existingPanel = messages.find(msg =>
          msg.embeds.length > 0 &&
          msg.embeds[0].title === 'Painel CL' &&
          msg.author.id === client.user.id
        );

        if (existingPanel) {
          await interaction.update({
            content: `Ja existe um painel CL neste canal.`,
            components: []
          });
          return;
        }

        const { createCLMessage } = require('./ui_cl_message.js');
        await channel.send(await createCLMessage());
        await interaction.update({
          content: `Add CL configurado em ${channel}`,
          components: []
        });
        return;
      }

      if (action === 'add_logs') {
        const dbPath = path.join(__dirname, 'userKeys.json');
        const db = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath, 'utf8')) : {};
        db.logsChannel = channel.id;
        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        await interaction.update({
          content: `Logs configurado em ${channel}`,
          components: []
        });
        return;
      }
    }

    if (interaction.isButton()) {
      switch (interaction.customId) {
        case 'cl_dm':
          return cldm.start(interaction, client);

        // No handler do botão cl_serv_grupo (já existe no seu código)  
        case 'cl_serv_grupo':
          try {
            const clServGrupo = require('./cl_servidor_grupo.js');
            return await clServGrupo.start(interaction, client);
          } catch (error) {
            console.error('Erro ao carregar cl_servidor_grupo:', error);
            return interaction.reply({
              content: 'Erro: Modulo CL SERV/GRUPO nao encontrado ou com erro.',
              ephemeral: true
            });
          }

        case 'token_menu':
          const tokenMenu = new StringSelectMenuBuilder()
            .setCustomId('token_menu_select')
            .setPlaceholder('Escolha uma opcao')
            .addOptions([
              {
                label: 'Ativar Token',
                description: 'Vincular novo token a sua conta',
                value: 'activate_token'
              },
              {
                label: 'Resetar Token',
                description: 'Remover token vinculado',
                value: 'reset_token'
              }
            ]);

          await interaction.reply({
            content: 'Gerenciar Token',
            components: [new ActionRowBuilder().addComponents(tokenMenu)],
            ephemeral: true
          });
          return;
      }
    }

    if (interaction.isModalSubmit() && interaction.customId === 'add_token_modal') {
      return addToken.handleModal(interaction);
    }

  } catch (error) {
    console.error('Erro na interacao:', error);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({
        content: 'Ocorreu um erro. Tente novamente.',
        ephemeral: true
      });
    } else {
      await interaction.reply({
        content: 'Ocorreu um erro. Tente novamente.',
        ephemeral: true
      });
    }
  }
});

process.on('unhandledRejection', (error) => {
  console.error('Erro nao tratado:', error);
});

process.on('uncaughtException', (error) => {
  console.error('Excecao nao capturada:', error);
});

client.login(process.env.TOKEN).catch(error => {
  console.error('Erro ao fazer login:', error);
  process.exit(1);
});

module.exports = { client, resetUserState };