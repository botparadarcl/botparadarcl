const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

async function createCLMessage() {
    const clEmbed = new EmbedBuilder()
        .setColor('#FFFFFF')
        .setTitle('Painel CL')
        .setDescription(
            'Utilize este sistema para deletar suas mensagens de forma segura e controlada.\n\n' +
            '• Token - Gerenciar o token da sua conta, o primeiro passo antes de seguir com o CL.\n' +
            '• CL - Deleta suas mensagens privadas com uma pessoa especifica atraves do ID da pessoa.\n' +
            '• CL SERV/GRUPO - Deleta suas mensagens em servidores ou grupos atraves do ID do canal.\n\n'
        )
        .setFooter({ 
            text: 'Sistema CL'
        })
        .setTimestamp();

    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('token_menu')
            .setLabel('Token')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('cl_dm')
            .setLabel('CL')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('cl_serv_grupo')
            .setLabel('CL SERV/GRUPO')
            .setStyle(ButtonStyle.Secondary)
    );

    return { 
        embeds: [clEmbed], 
        components: [row1]
    };
}

module.exports = { createCLMessage };