const fs = require('fs');
const path = require('path');
const usedPath = path.join(__dirname, 'usedOnce.json');
const addToken = require('./add_token.js');
const { EmbedBuilder } = require('discord.js');

function readUsed() {
    if (!fs.existsSync(usedPath)) return {};
    return JSON.parse(fs.readFileSync(usedPath, 'utf8'));
}

function writeUsed(data) {
    fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
}

function resetUserState(userId) {
    const used = readUsed();
    if (used.inProgress && used.user === userId) {
        used.inProgress = false;
        delete used.user;
        delete used.startTime;
        delete used.targetUserId;
        writeUsed(used);
        console.log(`Estado resetado para o usuário: ${userId}`);
    }
}

class PrivateMessageDeleter {
    constructor(userToken, userId) {
        this.options = {
            authToken: userToken,
            deleteDelay: 500, // Aumentado para evitar rate limit
            maxAttempts: 5,   // Aumentado para mais tentativas
            parallelDeletes: 2, // Reduzido para mais estabilidade
            fetchLimit: 100
        };
        this.userId = userId;
        this.state = {
            running: false,
            deletedCount: 0,
            failedCount: 0,
            totalMessages: 0,
            currentBatch: 0,
            startTime: null,
            emptyBatches: 0 // Contador de lotes vazios consecutivos
        };
    }

    async validateToken() {
        try {
            const response = await fetch('https://discord.com/api/v9/users/@me', {
                headers: {
                    'Authorization': this.options.authToken
                }
            });
            
            if (response.ok) {
                const userData = await response.json();
                return userData.id === this.userId;
            } else if (response.status === 401) {
                throw new Error('Token invalido');
            }
            return false;
        } catch (error) {
            console.error('Erro na validacao do token:', error);
            return false;
        }
    }

    async deletePrivateMessages(targetUserId) {
        if (this.state.running) {
            throw new Error('Já está em execução!');
        }

        if (!await this.validateToken()) {
            throw new Error('Token de autenticação inválido ou não pertence a este usuário');
        }

        this.state.running = true;
        this.state.deletedCount = 0;
        this.state.failedCount = 0;
        this.state.totalMessages = 0;
        this.state.currentBatch = 0;
        this.state.startTime = Date.now();
        this.state.emptyBatches = 0;

        try {
            console.log(`Iniciando exclusão para o usuário: ${targetUserId}`);

            const dmChannel = await this.findOrCreateDMChannel(targetUserId);
            if (!dmChannel) {
                throw new Error(`Não foi possível acessar o DM com: ${targetUserId}`);
            }

            console.log(`Canal DM acessado: ${dmChannel.id}`);
            
            // FASE 1: Deletar mensagens do usuário
            await this.fetchAndDeleteUserMessages(dmChannel.id);
            
            // FASE 2: Verificar se ainda há mensagens e tentar deletar novamente
            console.log('Iniciando verificação final...');
            const remaining = await this.checkRemainingMessages(dmChannel.id);
            
            if (remaining > 0) {
                console.log(`Encontradas ${remaining} mensagens restantes, reiniciando delecao...`);
                await this.fetchAndDeleteUserMessages(dmChannel.id, true);
                
                // Verificação final
                const finalRemaining = await this.checkRemainingMessages(dmChannel.id);
                if (finalRemaining > 0) {
                    console.log(`ATENÇÃO: Ainda restam ${finalRemaining} mensagens após segunda tentativa`);
                }
            }

            return this.generateReport();

        } catch (error) {
            console.error('Erro no processo:', error);
            return {
                success: false,
                error: error.message,
                ...this.getCurrentStats()
            };
        } finally {
            this.state.running = false;
            console.log('Processo finalizado');
        }
    }

    async fetchAndDeleteUserMessages(channelId, isRetry = false) {
        let beforeMessageId = null;
        let hasMoreMessages = true;
        let consecutiveEmpty = 0;
        const maxConsecutiveEmpty = 3; // Para após 3 lotes vazios consecutivos

        try {
            while (hasMoreMessages && this.state.running && consecutiveEmpty < maxConsecutiveEmpty) {
                try {
                    this.state.currentBatch++;
                    console.log(`Lote ${this.state.currentBatch} ${isRetry ? '(RETRY)' : ''} iniciado...`);

                    const messages = await this.fetchMessages(channelId, beforeMessageId);

                    if (messages.length === 0) {
                        console.log('Fim das mensagens alcançado');
                        consecutiveEmpty++;
                        hasMoreMessages = false;
                        continue;
                    }

                    // Buscar TODAS as mensagens do usuário neste canal
                    const userMessages = messages.filter(msg => msg.author.id === this.userId);
                    this.state.totalMessages += userMessages.length;

                    console.log(`${userMessages.length} mensagens do usuário no lote (Total: ${this.state.totalMessages})`);

                    if (userMessages.length === 0) {
                        console.log('Nenhuma mensagem do usuário neste lote');
                        consecutiveEmpty++;
                        beforeMessageId = messages[messages.length - 1]?.id;
                        
                        if (consecutiveEmpty >= maxConsecutiveEmpty) {
                            console.log(`Parando após ${maxConsecutiveEmpty} lotes vazios consecutivos`);
                            hasMoreMessages = false;
                        }
                        continue;
                    } else {
                        consecutiveEmpty = 0; // Reset counter quando encontrar mensagens
                    }

                    // Deletar em sequência para melhor confiabilidade
                    for (const msg of userMessages) {
                        if (!this.state.running) {
                            console.log('Processo interrompido pelo usuário');
                            return;
                        }

                        const success = await this.deleteSingleMessage(msg, channelId);
                        if (success) {
                            this.state.deletedCount++;
                            if (this.state.deletedCount % 10 === 0) {
                                console.log(`${this.state.deletedCount} mensagens deletadas...`);
                            }
                        } else {
                            this.state.failedCount++;
                        }

                        // Pequeno delay entre cada deleção
                        await this.delay(this.options.deleteDelay);
                    }

                    beforeMessageId = messages[messages.length - 1]?.id;

                    if (this.state.deletedCount % 50 === 0 && this.state.deletedCount > 0) {
                        const elapsed = (Date.now() - this.state.startTime) / 1000;
                        console.log(`Progresso: ${this.state.deletedCount} deletadas em ${elapsed.toFixed(1)}s`);
                    }

                } catch (error) {
                    console.error('Erro no processamento do lote:', error);
                    consecutiveEmpty++;
                    if (consecutiveEmpty >= maxConsecutiveEmpty) {
                        hasMoreMessages = false;
                    }
                    await this.delay(2000);
                }
            }

            const totalTime = (Date.now() - this.state.startTime) / 1000;
            console.log(`Fase de deleção concluída em ${totalTime.toFixed(1)} segundos`);

        } catch (error) {
            console.error('Erro geral no fetchAndDeleteUserMessages:', error);
            throw error;
        }
    }

    async checkRemainingMessages(channelId) {
        console.log('Verificando mensagens restantes...');
        let totalRemaining = 0;
        let beforeMessageId = null;
        let hasMore = true;
        let batchesChecked = 0;

        try {
            while (hasMore && batchesChecked < 10) { // Limite de verificação
                const messages = await this.fetchMessages(channelId, beforeMessageId);
                
                if (messages.length === 0) {
                    hasMore = false;
                    continue;
                }

                const userMessages = messages.filter(msg => msg.author.id === this.userId);
                totalRemaining += userMessages.length;
                
                batchesChecked++;
                beforeMessageId = messages[messages.length - 1]?.id;

                if (userMessages.length > 0) {
                    console.log(`Lote ${batchesChecked}: ${userMessages.length} mensagens do usuário ainda existem`);
                }
            }

            console.log(`Verificação concluída: ${totalRemaining} mensagens restantes encontradas`);
            return totalRemaining;

        } catch (error) {
            console.error('Erro na verificação:', error);
            return -1; // Indica erro na verificação
        }
    }

    generateReport() {
        const totalTime = (Date.now() - this.state.startTime) / 1000;
        const successRate = this.state.totalMessages > 0 ? 
            (this.state.deletedCount / this.state.totalMessages * 100).toFixed(1) : 0;
        
        const allDeleted = this.state.failedCount === 0 && this.state.deletedCount === this.state.totalMessages;
        
        return {
            success: allDeleted,
            deleted: this.state.deletedCount,
            failed: this.state.failedCount,
            total: this.state.totalMessages,
            batches: this.state.currentBatch,
            successRate: `${successRate}%`,
            totalTime: `${totalTime.toFixed(1)}s`,
            averageSpeed: totalTime > 0 ? `${(this.state.deletedCount / totalTime).toFixed(1)} msg/s` : '0 msg/s',
            completelyCleaned: allDeleted
        };
    }

    getCurrentStats() {
        const totalTime = this.state.startTime ? (Date.now() - this.state.startTime) / 1000 : 0;
        return {
            deleted: this.state.deletedCount,
            failed: this.state.failedCount,
            batches: this.state.currentBatch,
            totalTime: `${totalTime.toFixed(1)}s`,
            totalMessages: this.state.totalMessages
        };
    }

    async findOrCreateDMChannel(targetUserId) {
        try {
            const response = await fetch('https://discord.com/api/v9/users/@me/channels', {
                method: 'POST',
                headers: {
                    'Authorization': this.options.authToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    recipient_id: targetUserId
                })
            });

            if (response.ok) {
                return await response.json();
            } else if (response.status === 400) {
                const channelsResponse = await fetch('https://discord.com/api/v9/users/@me/channels', {
                    headers: {
                        'Authorization': this.options.authToken,
                        'Content-Type': 'application/json'
                    }
                });

                if (channelsResponse.ok) {
                    const channels = await channelsResponse.json();
                    const dmChannel = channels.find(channel =>
                        channel.type === 1 &&
                        channel.recipients?.some(recipient => recipient.id === targetUserId)
                    );

                    if (!dmChannel) {
                        throw new Error('Canal DM não encontrado na lista de canais.');
                    }
                    return dmChannel;
                }
                throw new Error(`Erro ao buscar canais: ${channelsResponse.status}`);
            } else if (response.status === 401) {
                throw new Error('Token invalido');
            } else {
                throw new Error(`Erro ao acessar DM: ${response.status}`);
            }
        } catch (error) {
            console.error('Erro no canal DM:', error);
            throw error;
        }
    }

    async fetchMessages(channelId, beforeId = null) {
        const params = new URLSearchParams({ limit: this.options.fetchLimit.toString() });
        if (beforeId) params.append('before', beforeId);

        try {
            const response = await fetch(
                `https://discord.com/api/v9/channels/${channelId}/messages?${params}`,
                {
                    headers: {
                        'Authorization': this.options.authToken,
                        'Content-Type': 'application/json'
                    }
                }
            );

            if (response.ok) {
                return await response.json();
            } else if (response.status === 429) {
                const rateLimitData = await response.json();
                const retryAfter = rateLimitData.retry_after * 1000;
                console.log(`Rate limit atingido. Esperando ${retryAfter}ms...`);
                await this.delay(retryAfter + 1000); // Buffer adicional
                return await this.fetchMessages(channelId, beforeId);
            } else if (response.status === 401) {
                throw new Error('Token invalido');
            } else if (response.status === 403) {
                throw new Error('Sem permissao para acessar este canal');
            } else if (response.status === 404) {
                throw new Error('Canal nao encontrado');
            } else {
                throw new Error(`Erro API: ${response.status}`);
            }
        } catch (error) {
            console.error('Erro na requisicao de mensagens:', error);
            throw error;
        }
    }

    async deleteSingleMessage(message, channelId) {
        let attempt = 0;

        while (attempt < this.options.maxAttempts) {
            try {
                const response = await fetch(
                    `https://discord.com/api/v9/channels/${channelId}/messages/${message.id}`,
                    {
                        method: 'DELETE',
                        headers: {
                            'Authorization': this.options.authToken,
                            'Content-Type': 'application/json'
                        }
                    }
                );

                if (response.ok) {
                    return true;
                } else if (response.status === 429) {
                    const rateLimitData = await response.json();
                    const retryAfter = rateLimitData.retry_after * 1000;
                    console.log(`Rate limit na delecao. Esperando ${retryAfter}ms...`);
                    await this.delay(retryAfter);
                    attempt++;
                } else if (response.status === 401) {
                    throw new Error('Token invalido');
                } else if (response.status === 404) {
                    console.log('Mensagem ja deletada ou nao encontrada');
                    return true; // Considera sucesso se já foi deletada
                } else if (response.status === 403) {
                    console.log('Sem permissao para deletar esta mensagem');
                    return false;
                } else {
                    console.log(`Erro ${response.status} na delecao, tentativa ${attempt + 1}`);
                    attempt++;
                    await this.delay(1000);
                }
            } catch (error) {
                console.error('Erro na tentativa de delecao:', error);
                attempt++;
                await this.delay(1000);
            }
        }

        console.log(`Falha apos ${this.options.maxAttempts} tentativas para mensagem ${message.id}`);
        return false;
    }

    stop() {
        this.state.running = false;
        console.log('Processo de delecao interrompido');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

module.exports = {
    async start(interaction, client) {
        const used = readUsed();
        if (used.inProgress && used.user === interaction.user.id) {
            const progressEmbed = new EmbedBuilder()
                .setColor(0xFFA500)
                .setTitle('Limpeza em Andamento')
                .setDescription('Você já tem uma limpeza em progresso.\n\nAguarde a limpeza atual ser concluída antes de iniciar uma nova.')
                .addFields(
                    { name: 'Status', value: 'Processando...', inline: true },
                    { name: 'Iniciado em', value: used.startTime ? new Date(used.startTime).toLocaleString('pt-BR') : 'Recentemente', inline: true }
                )
                .setFooter({ text: 'Aguarde a conclusão para iniciar uma nova limpeza.' });

            return await interaction.reply({ 
                embeds: [progressEmbed], 
                ephemeral: true 
            });
        }

        resetUserState(interaction.user.id);

        if (!addToken.hasToken(interaction.user.id)) {
            return interaction.reply({
                embeds: [{
                    color: 0xFF0000,
                    title: 'Token não vinculado!',
                    description: 'Você precisa vincular seu token primeiro!',
                    fields: [
                        {
                            name: 'Instruções:',
                            value: '1. Clique em "Token"\n2. Cole o token da sua conta Discord\n3. Use "CL" após vincular',
                        },
                    ],
                    footer: {
                        text: 'Caso tenha alguma dúvida, entre em contato com o suporte.',
                    },
                    timestamp: new Date(),
                }],
                ephemeral: true,
            });
        }

        const userTokenData = addToken.getUserTokenData(interaction.user.id);
        if (userTokenData && userTokenData.userId !== interaction.user.id) {
            const warningMessage = await interaction.reply({ 
                content: `||<@${interaction.user.id}>|| **ATENCAO**: O token vinculado nao pertence a sua conta!\n\nPor favor, use o comando **Token** → **Resetar Token** e depois vincule o token da **SUA** conta.`,
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await warningMessage.delete();
                } catch (error) {
                    console.log('Mensagem ja foi deletada ou nao encontrada');
                }
            }, 15000);
            
            return;
        }

        await interaction.reply({
            embeds: [{
                color: 0x0099ff,
                title: 'Digite o ID do usuario',
                description: 'Envie apenas o ID numerico da pessoa.\n\n**Voce tem 30 segundos para enviar o ID.**',
                fields: [
                    {
                        name: 'Como obter o ID:',
                        value: '- Ative o **Modo Desenvolvedor** nas configuracoes\n- Clique com botao direito no usuario → **"Copiar ID"**'
                    }
                ],
                footer: {
                    text: 'Solicitado por ' + interaction.user.username,
                    icon_url: interaction.user.displayAvatarURL()
                }
            }],
            ephemeral: true
        });

        const filter = m => m.author.id === interaction.user.id;
        const idCollector = interaction.channel.createMessageCollector({
            filter,
            time: 30000,
            max: 1
        });

        idCollector.on('collect', async targetMessage => {
            await targetMessage.delete().catch(() => { });
            const targetUserId = targetMessage.content.trim();

            if (!targetUserId.match(/^\d{17,20}$/)) {
                resetUserState(interaction.user.id);
                return interaction.followUp({
                    content: 'ID invalido!\n\n' +
                        'O ID deve conter 17-20 digitos numericos.\n' +
                        'Exemplo correto: 123456789012345678',
                    ephemeral: true
                });
            }

            used.inProgress = true;
            used.user = interaction.user.id;
            used.startTime = new Date().toISOString();
            used.targetUserId = targetUserId;
            writeUsed(used);

            const progressEmbed = new EmbedBuilder()
                .setColor(0x0099FF)
                .setTitle('Iniciando processo de exclusão...')
                .setDescription('Não feche a janela.')
                .setTimestamp();

            const progressMessage = await interaction.followUp({
                embeds: [progressEmbed],
                ephemeral: true
            });

            try {
                const userToken = addToken.getUserToken(interaction.user.id);
                const deleter = new PrivateMessageDeleter(userToken, interaction.user.id);

                let lastUpdate = 0;
                let progressUpdater;

                const updateProgress = async () => {
                    const now = Date.now();
                    if (now - lastUpdate < 2000) return;

                    lastUpdate = now;
                    try {
                        const stats = deleter.getCurrentStats();
                        const progressEmbed = new EmbedBuilder()
                            .setColor(0x0099FF)
                            .setTitle('Processando exclusao...')
                            .setDescription('Nao feche a janela.')
                            .addFields(
                                { name: 'Deletadas', value: deleter.state.deletedCount.toString(), inline: true },
                                { name: 'Falhas', value: deleter.state.failedCount.toString(), inline: true },
                                { name: 'Tempo', value: stats.totalTime, inline: true },
                                { name: 'Lotes', value: deleter.state.currentBatch.toString(), inline: true },
                                { name: 'Total', value: deleter.state.totalMessages.toString(), inline: true }
                            )
                            .setTimestamp();

                        await progressMessage.edit({ embeds: [progressEmbed] });
                    } catch (error) {
                        console.log('Mensagem de progresso ja atualizada');
                    }
                };

                const startTime = Date.now();
                progressUpdater = setInterval(updateProgress, 1000);

                console.log('Iniciando processo de deleção...');
                const result = await deleter.deletePrivateMessages(targetUserId);
                console.log('Processo de deleção concluído:', result);

                clearInterval(progressUpdater);
                resetUserState(interaction.user.id);

                const totalTime = Math.floor((Date.now() - startTime) / 1000);
                console.log(`Tempo total do processo: ${totalTime} segundos`);

                await this.sendLogs(client, interaction, targetUserId, result, totalTime);

                let finalEmbed;

                if (result.completelyCleaned) {
                    finalEmbed = new EmbedBuilder()
                        .setColor(0x00FF00)
                        .setTitle('CL foi concluído com sucesso.')
                        .setDescription('**Todas as suas mensagens foram deletadas completamente!**\n\nAltere a senha da sua conta para o token ser resetado. (Tudo por questão de segurança)')
                        .addFields(
                            { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                            //{ name: 'Taxa de sucesso', value: result.successRate, inline: true },
                            { name: 'Tempo total', value: result.totalTime, inline: true }
                            //{ name: 'Velocidade media', value: result.averageSpeed, inline: true },
                            //{ name: 'Lotes processados', value: result.batches.toString(), inline: true }
                        )
                        .setTimestamp();
                } else if (result.success) {
                    finalEmbed = new EmbedBuilder()
                        .setColor(0xFFA500)
                        .setTitle('⚠️ CL parcialmente concluído')
                        .setDescription('A maioria das mensagens foi deletada, mas algumas podem ter ficado para trás.\n\nAltere a senha da sua conta para o token ser resetado.')
                        .addFields(
                            { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                            { name: 'Mensagens falhadas', value: result.failed.toString(), inline: true },
                            { name: 'Taxa de sucesso', value: result.successRate, inline: true },
                            { name: 'Tempo total', value: result.totalTime, inline: true }
                        )
                        .setTimestamp();
                } else {
                    finalEmbed = new EmbedBuilder()
                        .setColor(0xFF0000)
                        .setTitle('❌ Erro na exclusão')
                        .setDescription(`Erro: ${result.error}`)
                        .addFields(
                            { name: 'Mensagens deletadas', value: result.deleted.toString(), inline: true },
                            { name: 'Mensagens falhadas', value: result.failed.toString(), inline: true },
                            { name: 'Tempo decorrido', value: result.totalTime, inline: true }
                        )
                        .setTimestamp();
                }

                // Mensagem final some após 20 segundos
                const finalMessage = await interaction.followUp({
                    embeds: [finalEmbed],
                    ephemeral: true,
                    fetchReply: true
                });

                // Deletar mensagem final após 20 segundos
                setTimeout(async () => {
                    try {
                        await finalMessage.delete();
                    } catch (error) {
                        console.log('Mensagem final já foi deletada ou não encontrada');
                    }
                }, 20000);

            } catch (error) {
                resetUserState(interaction.user.id);
                console.error('Erro crítico no processo:', error);

                const errorEmbed = new EmbedBuilder()
                    .setColor(0xFF0000)
                    .setTitle('❌ Erro crítico')
                    .setDescription(`Mensagem: ${error.message}\n\nSistema reiniciado. Tente novamente.`)
                    .setTimestamp();

                // Mensagem de erro também some após 20 segundos
                const errorMessage = await interaction.followUp({
                    embeds: [errorEmbed],
                    ephemeral: true,
                    fetchReply: true
                });

                setTimeout(async () => {
                    try {
                        await errorMessage.delete();
                    } catch (error) {
                        console.log('Mensagem de erro já foi deletada ou não encontrada');
                    }
                }, 20000);
            }
        });

        idCollector.on('end', (collected) => {
            if (collected.size === 0) {
                resetUserState(interaction.user.id);
                interaction.followUp({
                    content: 'Tempo esgotado para enviar o ID. Processo cancelado.',
                    ephemeral: true
                });
            }
        });
    },

    async sendLogs(client, interaction, targetUserId, result, totalTime) {
        try {
            const dbPath = path.join(__dirname, 'userKeys.json');
            if (fs.existsSync(dbPath)) {
                const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                if (db.logsChannel) {
                    const ch = client.channels.cache.get(db.logsChannel);
                    if (ch) {
                        if (result.completelyCleaned) {
                            await ch.send(`||<@${interaction.user.id}>|| Seu CL foi concluído com sucesso.`);
                            //await ch.send(`||<@${interaction.user.id}>|| ✅ CL concluída com SUCESSO TOTAL! Todas as ${result.deleted} mensagens foram deletadas.`);
                        } else if (result.success) {
                            await ch.send(`||<@${interaction.user.id}>|| ⚠️ CL parcial: ${result.deleted} deletadas, ${result.failed} falhas.`);
                        } else {
                            await ch.send(`||<@${interaction.user.id}>|| ❌ CL com erro: ${result.error}`);
                        }
                    }
                }
            }
        } catch (error) {
            console.error('Erro ao enviar logs:', error);
        }
    }
};