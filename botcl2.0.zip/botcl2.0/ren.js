const fs = require('fs');
const path = require('path');
const cooldownPath = path.join(__dirname, 'renCooldown.json');
const usedPath = path.join(__dirname, 'usedOnce.json');
const tokensPath = path.join(__dirname, 'userTokens.json');

function ensureFiles() {
  if (!fs.existsSync(cooldownPath)) {
    fs.writeFileSync(cooldownPath, JSON.stringify({}));
  }
  if (!fs.existsSync(usedPath)) {
    fs.writeFileSync(usedPath, JSON.stringify({}));
  }
  if (!fs.existsSync(tokensPath)) {
    fs.writeFileSync(tokensPath, JSON.stringify({}));
  }
}

function readCooldown() {
  ensureFiles();
  try {
    const data = fs.readFileSync(cooldownPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler cooldown:', error);
    return {};
  }
}

function writeCooldown(data) {
  try {
    fs.writeFileSync(cooldownPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar cooldown:', error);
    return false;
  }
}

function readUsed() {
  ensureFiles();
  try {
    const data = fs.readFileSync(usedPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler used:', error);
    return {};
  }
}

function writeUsed(data) {
  try {
    fs.writeFileSync(usedPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar used:', error);
    return false;
  }
}

function readTokens() {
  ensureFiles();
  try {
    const data = fs.readFileSync(tokensPath, 'utf8');
    return data ? JSON.parse(data) : {};
  } catch (error) {
    console.error('Erro ao ler tokens:', error);
    return {};
  }
}

function writeTokens(data) {
  try {
    fs.writeFileSync(tokensPath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao salvar tokens:', error);
    return false;
  }
}

async function doReset(interaction, autoRestart = false, client = null) {
  try {
    const tokensBackup = readTokens();
    
    writeUsed({});
    writeCooldown({});

    writeTokens(tokensBackup);

    console.log(`Sistema reiniciado por ${interaction?.user?.tag || 'SISTEMA'}`);
    console.log(`Processos ativos limpos - Tokens mantidos: ${Object.keys(tokensBackup).length}`);

    if (interaction && !autoRestart) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: `Sistema reiniciado com sucesso.\n` +
            `Todos os processos ativos foram finalizados para evitar sobrecarga.\n` +
            `Tokens preservados - usuarios podem continuar usando normalmente.`,
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: `Sistema reiniciado com sucesso.\n` +
            `Todos os processos ativos foram finalizados para evitar sobrecarga.\n` +
            `Tokens preservados - usuarios podem continuar usando normalmente.`,
          ephemeral: true
        });
      }
    }

    return true;

  } catch (error) {
    console.error('Erro no doReset:', error);

    if (interaction && !autoRestart) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: 'Erro ao reiniciar o sistema. Tente novamente.',
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: 'Erro ao reiniciar o sistema. Tente novamente.',
          ephemeral: true
        });
      }
    }
    return false;
  }
}

async function autoRestart(client) {
  try {
    console.log('Iniciando reinicio preventivo programado...');

    const tokensBackup = readTokens();
    
    writeUsed({});
    writeCooldown({});

    writeTokens(tokensBackup);

    console.log('Reinicio preventivo concluido - Processos ativos limpos');
    console.log(`Tokens mantidos: ${Object.keys(tokensBackup).length}`);

    scheduleNextRestart(client);

  } catch (error) {
    console.error('Erro no reinicio preventivo:', error);
  }
}

function scheduleNextRestart(client) {
  const twoHours = 2 * 60 * 60 * 1000;

  setTimeout(() => {
    autoRestart(client);
  }, twoHours);

  console.log('Proximo reinicio automatico agendado para 2 horas');
}

module.exports = {
  async resetAll(interaction) {
    try {
      console.log(`Solicitacao de reinicio por ${interaction.user.tag}`);

      if (!interaction.member.permissions.has('Administrator')) {
        return interaction.reply({
          content: 'Apenas administradores podem usar este comando.',
          ephemeral: true
        });
      }

      await interaction.reply({
        content: 'Reiniciando sistema CL...',
        ephemeral: true
      });
      
      return await doReset(interaction, false);

    } catch (error) {
      console.error('Erro no resetAll:', error);

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: 'Erro ao processar reinicio. Tente novamente.',
          ephemeral: true
        });
      } else {
        await interaction.reply({
          content: 'Erro ao processar reinicio. Tente novamente.',
          ephemeral: true
        });
      }
    }
  },

  getSystemStatus() {
    const used = readUsed();
    const tokens = readTokens();

    return {
      inProgress: used.inProgress || false,
      currentUser: used.user || null,
      startTime: used.startTime || null,
      totalTokens: Object.keys(tokens).length
    };
  },

  startAutoRestart(client) {
    console.log('Iniciando sistema de reinicio automatico (2 horas)');
    scheduleNextRestart(client);
  }
};